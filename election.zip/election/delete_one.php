<?php
        require 'connectdb.php';
        
        $one_number = $_GET['one_number'];
        
        $q = "DELETE FROM onedb WHERE one_number='$one_number'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_one.php");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);
        
        
