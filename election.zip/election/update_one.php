<?php
        require 'connectdb.php';
        
        $one_number = $_GET['one_number'];
        $qone = "SELECT * FROM onedb WHERE one_number='$one_number'";
        $resone = mysqli_query($dbcon, $qone);
        $rowone = mysqli_fetch_array($resone, MYSQLI_ASSOC);
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>แก้ไขข้อมูล</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
        <h2>แก้ไขข้อมูล</h2>
        <form action="updated_one.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>แก้ไขข้อมูล</legend>
          <label>หมายเลขผู้สมัค: </label><input name="one_number" type="text" id="one_number" size="20" value="<?php echo $rowone['one_number']; ?>" >
          <label>ชื่อ: </label><input name="one_name" type="text" id="one_name" size="20" value="<?php echo $rowone['one_name']; ?>" >
          <label>สกุล: </label><input name="one_lastname" type="text" id="one_lastname" size="20" value="<?php echo $rowone['one_lastname']; ?>" >
          <label>รหัสนักศึกษา: </label><input name="one_id" type="text" id="one_id" size="20" value="<?php echo $rowone['one_id']; ?>" >
          
          <label>คณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="one_faculty" id="one_faculty">

                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                if ($row[0]==$rowone['one_faculty']) {
                                    echo "<option value='$row[0]' selected>$row[1]</option>";
                                } else {                                  
                                echo "<option value='$row[0]'>$row[1]</option>";
                                }
                            }
                  ?>
              </select>

        <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="one_year" value="1" id="one_year_1" <?php if ($rowone['one_year']=='1') echo "checked"; ?>> 
           ปี1</label>          
           <label>
               <input type="radio" name="one_year" value="2" id="one_year_2" <?php if ($rowone['one_year']=='2') echo "checked"; ?>>
           ปี2</label>
           <label>              
               <input type="radio" name="one_year" value="3" id="one_year_3" <?php if ($rowone['one_year']=='3') echo "checked"; ?>>
           ปี3</label>
           <label>               
               <input type="radio" name="one_year" value="4" id="one_year_4" <?php if ($rowone['one_year']=='4') echo "checked"; ?>>
           ปี4</label>
           <label>              
               <input type="radio" name="one_year" value="5" id="one_year_5" <?php if ($rowone['one_year']=='5') echo "checked"; ?>>
           ปี5</label>
           <label>    
               <input type="radio" name="one_year" value="6" id="one_year_6" <?php if ($rowone['one_year']=='6') echo "checked"; ?>>
           ปี6</label>
           
              <br><br>
              <input type="hidden" name="one_number" value="<?php echo $rowone['one_number']; ?>"> 
              <input name="submit" type="submit" id="submit" value="แก้ไขข้อมูล">
      </fieldset>        
      </form>
    </body>
</html>
