<?php
        require 'connectdb.php';
        
        $studentv_id = $_GET['studentv_id'];
        $qvoter = "SELECT * FROM voterdb WHERE studentv_id='$studentv_id'";
        $resvoter = mysqli_query($dbcon, $qvoter);
        $rowvoter = mysqli_fetch_array($resvoter, MYSQLI_ASSOC);
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>แก้ไขข้อมูล</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
        <h2>แก้ไขข้อมูล</h2>
        <form action="updated_voter.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>แก้ไขข้อมูล</legend>
          <label>ชื่อ: </label><input name="studentv_name" type="text" id="studentv_name" size="20" value="<?php echo $rowvoter['studentv_name']; ?>" >
          <label>สกุล: </label><input name="studentv_lastname" type="text" id="studentv_lastname" size="20" value="<?php echo $rowvoter['studentv_lastname']; ?>" >
          <label>รหัสนักศึกษา: </label><input name="studentv_id" type="text" id="studentv_id" size="20" value="<?php echo $rowvoter['studentv_id']; ?>" >
          
          <label>คณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="t_faculty" id="t_faculty">

                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                if ($row[0]==$rowvoter['studentv_faculty']) {
                                    echo "<option value='$row[0]' selected>$row[1]</option>";
                                } else {                                  
                                echo "<option value='$row[0]'>$row[1]</option>";
                                }
                            }
                  ?>
              </select>

        
           <label>ชั้นปี: </label>
           <?php
                $q = "SELECT * FROM onedb ";
                $result = mysqli_query($dbcon, $q);
          ?>
              <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="studentv_year" value="1" id="studentv_year_1" <?php if ($rowvoter['studentv_year']=='1') echo "checked"; ?>>
           ปี1</label>          
           <label>
               <input type="radio" name="studentv_year" value="2" id="studentv_year_2" <?php if ($rowvoter['studentv_year']=='2') echo "checked"; ?>>
           ปี2</label>
           <label>              
               <input type="radio" name="studentv_year" value="3" id="studentv_year_3" <?php if ($rowvoter['studentv_year']=='3') echo "checked"; ?>>
           ปี3</label>
           <label>               
               <input type="radio" name="studentv_year" value="4" id="studentv_year_4" <?php if ($rowvoter['studentv_year']=='4') echo "checked"; ?>>
           ปี4</label>
           <label>              
               <input type="radio" name="studentv_year" value="5" id="studentv_year_5" <?php if ($rowvoter['studentv_year']=='5') echo "checked"; ?>>
           ปี5</label>
           <label>    
               <input type="radio" name="studentv_year" value="6" id="studentv_year_6" <?php if ($rowvoter['studentv_year']=='6') echo "checked"; ?>>
           ปี6</label>
           
              <br>
              <input type="hidden" name="one_number" value="<?php echo $rowone['one_number']; ?>"> 
              <input name="submit" type="submit" id="submit" value="แก้ไขข้อมูล">
      </fieldset>        
      </form>
    </body>
</html>
