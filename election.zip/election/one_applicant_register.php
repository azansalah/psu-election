<?php
        require 'connectdb.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ลงทะเบียนผู้ลงสมัคเลือกตั้งแบบเดี่ยว</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
      <h2>ลงทะเบียนผู้ลงสมัคเลือกตั้งแบบเดี่ยว</h2>
      <form action="one_register.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>กรอกข้อมูล</legend>
          <label>หมายเลขผู้สมัค: </label><input name="one_number" type="text" id="one_number" size="20" >
          <label>ชื่อ: </label><input name="one_name" type="text" id="one_name" size="20" >
          <label>สกุล: </label><input name="one_lastname" type="text" id="one_lastname" size="20">
          <label>รหัสนักศึกษา: </label><input name="one_id" type="text" id="one_id" size="20">
          
          <label>คณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="one_faculty" id="one_faculty">
                  <option value="">---เลือกคณะ---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[0]'>$row[1]</option>";
                            }
                  ?>
              </select>

        
           <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="one_year" value="1" id="one_year_1">
           ปี1</label>          
           <label>
               <input type="radio" name="one_year" value="2" id="one_year_2">
           ปี2</label>
           <label>              
               <input type="radio" name="one_year" value="3" id="one_year_3">
           ปี3</label>
           <label>               
               <input type="radio" name="one_year" value="4" id="one_year_4">
           ปี4</label>
           <label>              
               <input type="radio" name="one_year" value="5" id="one_year_5">
           ปี5</label>
           <label>    
               <input type="radio" name="one_year" value="6" id="one_year_6">
           ปี6</label>
           
              <br>
              
              <input name="submit" type="submit" id="submit" value="บันทึก">
      </fieldset>        
      </form>
    </body>
</html>


<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

