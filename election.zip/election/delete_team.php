<?php
        require 'connectdb.php';
        
        $party_number = $_GET['party_number'];
        
        $q = "DELETE FROM teamdb WHERE party_number='$party_number'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_team.php");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);
        
        
