<?php
        include 'session';
        session_start();
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
    </head>
    <body>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <?php
                    include 'header.php';
            ?>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
                   <?php
                        if ($_GET['code'] == 1) {
                            echo '<div class="uk-alert uk-alert-success"> <h2>บันทึกข้อมูลเรียบร้อยแล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="show_info.php">';
                        }
                   ?>    
                </div>
                <?php
                        include 'right.php';
                ?>
            </div><!-- end grid -->                  
        </div>          
    </body>
</html>
