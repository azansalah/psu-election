<?php
        require 'connectdb.php';
        $electionset_id = $_GET['electionset_id'];
        $year = $_GET['elect_year'];
        $elect_name = $_GET['elect_name'];
        $elect_year = $_GET['elect_year'];
        $elect_date = $_GET['elect_date'];
        $elect_starttime = $_GET['elect_starttime'];
        $elect_endtime = $_GET['elect_endtime'];
        $faculty = $_GET['faculty'];
        
        $query = "SELECT * FROM ongkan_team WHERE election_year = '$year' ";
        $result1 = mysqli_query($dbcon, $query);
        
        $query2 = "SELECT COUNT(ongkan_num) FROM resault_ongkan WHERE ongkan_num = 1 " ;
        $result2 = mysqli_query($dbcon, $query2);
        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);
                
        $result1_ongkan = $row2['COUNT(ongkan_num)'];       
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <?php
        include 'header_admin.php';                  
    ?>
    <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
        <div class="uk-grid" data-uk-grid-margin> 
            <div class="uk-width-medium-5-4" style="font-coler: " >
            <center>
            <body>  
                <br><h1>ข้อมูลการลงสมัคเลือกตั้งองค์การบริหาร องค์การนักศึกษา <?php echo "$year"; ?> </h1><br>
                <button type="button" class="btn btn-secondary" value="เพิ่มสมาชิค" onclick="window.location.href='frm_insert_ongkan_team.php?electionset_id=<?php echo $electionset_id; ?>&elect_name=<?php echo $elect_name;?>&elect_year=<?php echo $elect_year;?>&elect_date=<?php echo $elect_date;?>&elect_starttime=<?php echo $elect_starttime;?>&elect_endtime=<?php echo $elect_endtime;?>'"><h3>เพิ่มพรรค</h3></button><br><br>
                    <table class="table">
                        <thead class="thead-dark" >
                        <tr align="center">
                            <th scope="col">โลโก้พรรค</th>
                            <th scope="col">หมายเลขพรรค</th>
                            <th scope="col">ชื่อพรรค</th>
                            <th scope="col">รายละเอียด</th>
                            <th scope="col">แก้ไข</th>
                            <th scope="col">ลบ</th>
                        </tr>
                    <?php
                        while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)) {
                    ?>
                        <tr align="center">
                            <td><img src="image_ongkan/logo/<?php echo $row1[4];?>" width="100px" height="100px"></td>
                            <form method="GET" action="frm_ongkan_candidate.php">    
                            <td><h3><?php echo $row1[0];?></h3><input align="right" type="hidden" name="ongkan_num" value="<?php echo $row1[0];?>" readonly></td>
                            <td><h3><?php echo $row1[1];?></h3><input type="hidden" name="ongkan_name" value="<?php echo $row1[1];?>" readonly></td>
                            <td><button type="submit" class="btn btn-secondary" value="ดูสมาชิกพรรค" onClick="this.form.action='show_electionongkan.php'; submit()"><h3>ดูสมาชิกพรรค</h3></button></td>
                            <td><a href="update_ongkan_team.php?electionset_id=<?php echo $row1[2]; ?>&id1=<?php echo $electionset_id; ?>&elect_name=<?php echo $elect_name;?>&elect_fac=<?php echo $faculty; ?>&elect_year=<?php echo $elect_year;?>&elect_date=<?php echo $elect_date;?>&elect_starttime=<?php echo $elect_starttime;?>&elect_endtime=<?php echo $elect_endtime;?>' " onclick="return confirm('คุณต้องการแก้ไขเบอร์ <?php echo "$row1[0]"; ?> พรรค <?php echo "$row1[1]"; ?> ');">แก้ไข</a></td>
                            <td><a href="delete_ongkan_team.php?electionset1_id=<?php echo $row1[2]; ?>&electionset_id=<?php echo $electionset_id; ?>&elect_name=<?php echo $elect_name;?>&elect_year=<?php echo $elect_year;?>&elect_date=<?php echo $elect_date;?>&elect_starttime=<?php echo $elect_starttime;?>&elect_endtime=<?php echo $elect_endtime;?>' " onclick="return confirm('คุณต้องการลบเบอร์ <?php echo "$row1[0]"; ?> พรรค <?php echo "$row1[1]"; ?> ');">ลบ</a></td>
                            </form>
                        </tr>
                    <?php 
                        }
                        mysqli_free_result($result1);
                        mysqli_close($dbcon);
                    ?>
                    </table>   
            </body>
            </center>
            </div>                               
        </div>                      
    </div><!-- end grid -->                            
    <?php
        include 'footer.php';                          
    ?> 
</html>


