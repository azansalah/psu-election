<?php
        require 'connectdb.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ลงทะเบียน</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
      <h2>ลงทะเบียนผู้มีสิทธิเลือกตั้ง</h2>
      <form action="voter_register.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>กรอกข้อมูล</legend>
          <label>ชื่อ: </label><input name="studentv_name" type="text" id="student_name" size="20" >
          <label>สกุล: </label><input name="studentv_lastname" type="text" id="student_lastname" size="20">
          <label>รหัสนักศึกษา: </label><input name="studentv_id" type="text" id="student_id" size="20">
  
          <label>คณะ: </label>
          <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="studentv_faculty" id="studentv_faculty">
                  <option value="">---เลือกคณะ---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[0]'>$row[1]</option>";
                            }
                  ?>
                </select>  
              <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="studentv_year" value="1" id="studentv_year_1">
           ปี1</label>          
           <label>
               <input type="radio" name="studentv_year" value="2" id="studentv_year_2">
           ปี2</label>
           <label>              
               <input type="radio" name="studentv_year" value="3" id="studentv_year_3">
           ปี3</label>
           <label>               
               <input type="radio" name="studentv_year" value="4" id="studentv_year_4">
           ปี4</label>
           <label>              
               <input type="radio" name="studentv_year" value="5" id="studentv_year_5">
           ปี5</label>
           <label>    
               <input type="radio" name="studentv_year" value="6" id="studentv_year_6">
           ปี6</label>
              
              <br>
              
              <input name="submit" type="submit" id="submit" value="บันทึก">
      </fieldset>        
      </form>
    </body>
</html>
