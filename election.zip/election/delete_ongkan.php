<?php
        require 'connectdb.php';
        
        $electionset_id = $_GET['electionset_id'];
        $ongkan_num = $_GET['ongkan_num'];
        $ongkan_name = $_GET['ongkan_name'];
        
        $q = "DELETE FROM electionset WHERE electionset_id='$electionset_id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: create_election_ongkan_show.php");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);