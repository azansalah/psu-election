<?php

    $elec_type = $_POST['electionset_name'];
    
    if($elec_type == 003){
        
        header("Location: frm_select_facultysamo.php");
    }
    else if($elec_type == 002){
        
        header("Location: frm_select_facultysapa.php");
    }
    else{
        
        header("Location: frm_insert_ongkan_team.php");
    }
            

