<?php
       require 'connectdb.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>การเลือกตั้งสโมสรนักศึกษา</h2> 
        <form action="frm_insert_samo_team.php" method="post" enctype="multipart/form-data" id="form1">
            <fieldset>
                <legend>เลือกคณะ</legend>          
                
              <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
              ?>
              <select name="faculty" id="faculty">
                  <option value="">---เลือกคณะ---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[1]'>$row[1]</option>";
                            }
                  ?>
              </select>
                          
              <br><br>
              <input name="submit" type="submit" id="submit" value="ต่อไป">
            </fieldset>
        </form>
    </body>
</html>
