<?php

        require 'connectdb.php';
        
        $electionset_name = 2;
        $year = $_POST['year'];
        $date = $_POST['date'];
        $starttime = $_POST['starttime'];
        $endtime = $_POST['endtime'];
        $win_score_normal = $_POST['win_score_normal'];
        $win_score_fac = $_POST['win_score_fac'];
        
        $q = "INSERT INTO electionset_sapa (electionset_name, electionset_date, electionset_starttime, electionset_endtime, electionset_year, win_score_normal, win_score_fac) VALUES ('$electionset_name', '$date', '$starttime', '$endtime', '$year', '$win_score_normal', '$win_score_fac')";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            header("Location: create_election_sapa_show.php");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);


