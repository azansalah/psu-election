<?php
       require 'connectdb.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h2>เลือกประเภทการเลือกตั้ง</h2>
        <a href='show_ongkan_team.php'>แสดงข้อมูลการเลือกตั้งองค์การบริหาร องค์การนักศึกษา</a><br>
        <a href='show_sapa_team.php'>แสดงข้อมูลการเลือกตั้งสภานักศึกษา</a><br>
        <a href='show_samo_team.php'>แสดงข้อมูลการเลือกตั้งสโมสรนักศึกษา</a>
        <br><br>
        <form action="check_type.php" method="post" enctype="multipart/form-data" id="form1">
            <fieldset>
                <legend>เลือกประเภทการเลือกตั้ง</legend>          
                    
        <label>การเลือกตั้ง: </label>
              <?php
                $q = "SELECT * FROM election_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="electionset_name" id="electionset_name">
                  <option value="">---เลือกการเลือกตั้ง---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[0]'>$row[1]</option>";
                            }
                  ?>
              </select>
              <br><br>
              <input name="submit" type="submit" id="submit" value="ต่อไป">
            </fieldset>
        </form>
    </body>
</html>
