<?php   
        include 'session.php';
        require 'connectdb.php';
        
        
        $faculty = $_POST['faculty'];
        
        
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>เลือกตั้งสสภานักศึกษา</title>
        
    </head>
    <body>
        <h2>การเลือกตั้งสภานักศึกษา</h2>
        <h2>คณะ<?php echo $faculty; ?></h2>
        
        <form name="sapa_team" method="POST" action="insert_sapa_team.php">
            <fieldset>
                <legend>พรรคการเลือกตั้ง</legend>
            
            <label>หมายเลขพรรค: </label>
            <input type="text" name="team_number">
            <label>ชื่อพรรค: </label>
            <input type="text" name="team_name">
            <input type="hidden" name="faculty" value="<?php echo $faculty?>">
            
            <input type="submit" id="submit" value="เพิ่มพรรค">
        </form>
        
        <br>
        <br>
        </fieldset>
        
        
    </body>
</html>


