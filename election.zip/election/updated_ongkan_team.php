<?php
        require 'connectdb.php';
        $elect_name = $_GET['elect_name'];
        $elect_fac = $_GET['elect_fac'];
        $elect_year = $_GET['elect_year'];
        $elect_date = $_GET['elect_date'];
        $elect_starttime = $_GET['elect_starttime'];
        $elect_endtime = $_GET['elect_endtime'];
        
        $id = $_GET['id'];
        $id1 = $_GET['id1'];
        $team_number = $_GET['team_number'];
        $team_name = $_GET['team_name'];
        
     $q = "UPDATE ongkan_team SET team_number = '$team_number', team_name = '$team_name' WHERE electionset_id = '$id' ";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
         header("Location: show_ongkan_team.php?electionset_id=$id1&elect_name=$elect_name&elect_year=$elect_year&elect_date=$elect_date&elect_starttime=$elect_starttime&elect_endtime=$elect_endtime");
     } else {
         echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon); 
     }
     
     mysqli_close($dbcon);