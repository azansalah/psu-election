<?php
        require 'connectdb.php';
        
        $studentv_id = $_GET['studentv_id'];
        
        $q = "DELETE FROM voterdb WHERE studentv_id='$studentv_id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_voter.php");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);
        
        
