<form method="post">
<input type="button" value="ไป a.php" onClick="this.form.action='a.php'; submit()">
<input type="button" value="ไป b.php" onClick="this.form.action='b.php'; submit()">
</form>