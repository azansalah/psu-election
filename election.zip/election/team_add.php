<?php
        include 'secure/session.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>ยินดีต้อนรับ</h1>
        <p>คุณ <?php echo $s_login_username; ?> อีเมล: <?php echo $s_login_email; ?></p>
        
        
        <p>
            <a href="frm_insert_ongkan_team.php">องค์การบริหาร องค์การนักศึกษา</a>
            <br>
            <a href="frm_select_facultysapa.php">สภานักศึกษา</a>
            <br>
            <a href="frm_select_facultysamo.php">สโมสรนักศึกษา</a>
        </p>
        
        <hr>
    </body>
</html>
