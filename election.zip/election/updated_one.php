<?php
        require 'connectdb.php';
        
        $one_number = $_POST['one_number'];
        $one_name = $_POST['one_name'];
        $one_lastname = $_POST['one_lastname'];
        $one_id = $_POST['one_id'];
        $one_faculty = $_POST['one_faculty'];
        $one_year = $_POST['one_year'];
        
     $q = "UPDATE onedb SET one_name='$one_name',one_lastname='$one_lastname',one_id='$one_id',one_faculty='$one_faculty',one_year='$one_year' WHERE one_number='$one_number'";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
         echo "แก้ไขข้อมูลเรียบร้อยเเล้ว";
         echo "<hr>";
         echo "<a href='show_one.php'>แสดงข้อมูล</a>";
     } else {
         echo "เกิดข้อผิดพลาด" . mysqli_errno($dbcon);    
     }
     
     mysqli_close($dbcon);
 