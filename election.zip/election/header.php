<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    
<nav class="navbar navbar-expand-lg navbar-dark  bg-dark">
        <a class="navbar-brand" href="#"style="font-size: xx-large" >PSU ELECTION</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item ">
                        <a class="nav-link" href="main.php" style="font-size: x-large ">หน้าแรก</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php" style="font-size: x-large ">ติดต่อเรา</a>
                    </li>
                    <?php
                            if (isset($_SESSION['is_member'])){
                    ?>
                    <li class="nav-item">
                        <a class="nav-link" href="show_info.php" style="font-size: x-large ">ข้อมูลส่วนตัว</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="font-size: x-large ">การเลือกตั้ง</a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown" >
                                <a class="dropdown-item" href="election_ongkan.php">องค์การบริหาร องการนักศึกษา</a>
                                <a class="dropdown-item" href="election_sapa.php">สภานักศึกษา</a>
                                <a class="dropdown-item" href="election_samo.php">สโมสรนักศึกษา</a>                                  
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php" style="font-size: x-large " onclick="return confirm('ต้องการออกจากระบบหรือไม่');">ออกจากระบบ</a>
                    </li>
                    <?php } else { ?>
                    <li class="nav-item">
                        <a class="nav-link" style="font-size: x-large " href="frm_register.php">ลงทะเบียน</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" style="font-size: x-large " href="index.php">เข้าระบบ</a>
                    </li>
                    <?php } ?>
                </ul>
            </div>
    </nav>
    