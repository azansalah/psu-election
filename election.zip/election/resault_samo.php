<?php
        require 'connectdb.php';
        
        $year = $_GET['elect_year'];
        $faculty = $_GET['elect_fac'];
        
        $query = "SELECT * FROM samo_team WHERE faculty = '$faculty' ";
        $result1 = mysqli_query($dbcon, $query);
        
        $query2 = "SELECT COUNT(election_year) FROM samo_team WHERE election_year = '$year' ";   
        $result2 = mysqli_query($dbcon, $query2);
        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);                
        $result1_ongkan = $row2['COUNT(election_year)'];
        
        if($faculty == "วิทยาศาสตร์"){
            $samo_fac_check = "sc";
        }
        if($faculty == "วิศวกรรมศาสตร์"){
            $samo_fac_check = "en";
        }
        if($faculty == "ทรัพยากรธรรมชาติ"){
            $samo_fac_check = "rn";
        }
        if($faculty == "อุตสาหกรรมเกษตร"){
            $samo_fac_check = "agro";
        }
        if($faculty == "การจัดการสิ่งแวดล้อม"){
            $samo_fac_check = "em";
        }
        if($faculty == "แพทยศาสตร์"){
            $samo_fac_check = "md";
        }
        if($faculty == "พยาบาลศาสตร์"){
            $samo_fac_check = "nu";
        }
        if($faculty == "วิทยาลัยนานาชาติ"){
            $samo_fac_check = "uic";
        }
        if($faculty == "ทันตแพทยศาสตร์"){
            $samo_fac_check = "dt";
        }
        if($faculty == "เภสัชศาสตร์"){
            $samo_fac_check = "ps";
        }
        if($faculty == "วิทยาการจัดการ"){
            $samo_fac_check = "ms";
        }
        if($faculty == "ศิลปศาสตร์"){
            $samo_fac_check = "la";
        }
        if($faculty == "เศรษฐศาสตร์"){
            $samo_fac_check = "econ";
        }
        if($faculty == "นิติศาสตร์"){
            $samo_fac_check = "law";
        }
        if($faculty == "การแพทย์แผนไทย"){
            $samo_fac_check = "tm";
        }
        if($faculty == "เทคนิคการแพทย์"){
            $samo_fac_check = "md";
        }
        if($faculty == "สัตวแพทยศาสตร์"){
            $samo_fac_check = "vs";
        }
        
        $query4 = "SELECT COUNT(samo_num) FROM resault_samo_$samo_fac_check WHERE election_year = '$year'";
        $result4 = mysqli_query($dbcon, $query4);
        $row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC);                
        $all = $row4['COUNT(samo_num)'];
        
        $query5 = "SELECT COUNT(samo_num) FROM resault_samo_$samo_fac_check WHERE election_year = '$year' AND vote_no = '0' ";
        $result5 = mysqli_query($dbcon, $query5);
        $row5 = mysqli_fetch_array($result5, MYSQLI_ASSOC);                
        $vote = $row5['COUNT(samo_num)'];
        
        $query6 = "SELECT COUNT(samo_num) FROM resault_samo_$samo_fac_check WHERE election_year = '$year' AND vote_no = '1'";
        $result6 = mysqli_query($dbcon, $query6);
        $row6 = mysqli_fetch_array($result6, MYSQLI_ASSOC);                
        $vote_no = $row6['COUNT(samo_num)'];
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <center>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
        <br>
        <h1>ข้อมูลการลงสมัคเลือกตั้งสโมสรนักศึกษา คณะ <?php echo "$faculty"; ?> ปีการศึกษา <?php echo "$year"; ?> </h1> 
        <br><br>
        <table class="table">
            <thead class="thead-dark" >
            <tr align="center">
                <th scope="col">โลโก้พรรค</th>
                <th scope="col">หมายเลขพรรค</th>
                <th scope="col">ชื่อพรรค</th>
                <th scope="col">คะแนน</th>
            </tr>
        <?php
                while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)) {
        ?>
        <tr align="center">
            <td><img src="image_samo/logo/<?php echo $row1[4];?>" width="100px" height="100px"></td>
            <form method="GET" action="frm_samo_candidate.php">
            <td align="center"><h1><?php echo $row1[0];?></h1><input type="hidden" name="samo_num" value="<?php echo $row1[0];?>" readonly></td>
            <td align="center"><h3><?php echo $row1[1];?></h3><input type="hidden" name="samo_name" value="<?php echo $row1[1];?>" readonly></td>
            <input type="hidden" name="samo_fac" value="<?php echo $row1[2];?>" readonly></td>
            <td><font color="red" > <h1><?php 
            $query3 = "SELECT COUNT(samo_num) FROM resault_samo_$samo_fac_check WHERE election_year = '$year' AND samo_num = '$row1[0]'";
            $result3 = mysqli_query($dbcon, $query3);
            $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);                
            $result3_ongkan = $row3['COUNT(samo_num)'];
            echo $result3_ongkan;       
            ?></h1></font></td>
            </form>
        </tr>
        
        <?php 
                }
                mysqli_free_result($result1);
                mysqli_free_result($result2);
                mysqli_close($dbcon);
         ?>
        </table>
         <br><h1>สรุปสถิติการเข้าร่วมการเลือกตั้ง</h1><br>
         <table class="table">
            <thead class="thead-dark" >
            <tr align="center">
                <th scope="col">จำนวนผู้มาใช้สิทธิ์ทั้งหมด</th>
                <th scope="col">ลงคะแนน</th>
                <th scope="col">ไม่ประสงค์ลงคะแนน</th>
            </tr>
            
        <tr align="center">
            <td><h2><?php echo $all;?></h2></td>
            <td><h2><?php echo $vote;?></h2></td>
            <td><h2><?php echo $vote_no;?></h2></td>
            </form>
        </tr>
        </table>
        
        </center>                    
                </div>                               
            </div>                      
        </div><!-- end grid -->                            
    </body><br><br><br>
    <?php
    include 'footer.php';                          
    ?>
</html>


