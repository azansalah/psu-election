<div id="offcanvas" class="uk-offcanvas">
            <div class="uk-offcanvas-bar">
                <ul class="uk-nav uk-nav-offcanvas">
                    <li class="uk-active">
                        <a href="index.php">หน้าแรก</a>
                    </li>
                    <li>
                        <a href="all_news.php">ข่าวทั้งหมด</a>
                    </li>                                      
                    <li>
                        <a href="layouts_contact.html">ติดต่อเรา</a>
                    </li>
                    <li>
                        <a href="secure/index.php">เข้าระบบ</a>                      
                    </li>
                    <li>
                        <a href="frm_register.php">ลงทะเบียน</a>
                        
                    </li>
                </ul>
            </div>
        </div>

