<?php
        include 'session.php';
        session_start();
        require 'connectdb.php';
        
        $now_year = (date("Y")+543);
        $vote = $_GET['vote'];
        
        $query1 = "SELECT * FROM electionset_sapa";
        $result1 = mysqli_query($dbcon, $query1);
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        
        $query2 = "SELECT * FROM resault_sapa WHERE std_id = '$s_std_id' AND sapa_type = 'normal' ";
        $result2 = mysqli_query($dbcon, $query2);
        
        $query21 = "SELECT * FROM resault_sapa WHERE std_id = '$s_std_id' AND vote_no = '1' ";
        $result21 = mysqli_query($dbcon, $query21);
        
        
        
        $query3 = "SELECT * FROM sapa_candidate WHERE type ='normal' AND year = '$now_year' ";
        $result3 = mysqli_query($dbcon, $query3);
        
        $query4 = "SELECT * FROM sapa_candidate WHERE type ='fac' AND year = '$now_year' AND sapa_fac = '$s_faculty' ";
        $result4 = mysqli_query($dbcon, $query4);
        
        
        $query5 = "SELECT * FROM electionset_sapa" ;
        $result5 = mysqli_query($dbcon, $query5);
        $row5 = mysqli_fetch_array($result5, MYSQLI_ASSOC);
        
        $query6 = "SELECT * FROM resault_sapa WHERE std_id = '$s_std_id' AND sapa_type = 'fac' ";
        $result6 = mysqli_query($dbcon, $query6);
        
        $query7 = "SELECT * FROM resault_sapa WHERE std_id = '$s_std_id' AND sapa_type = 'fac' ";
        $result7 = mysqli_query($dbcon, $query7);
        
        $query8 = "SELECT * FROM sapa_candidate WHERE type = 'fac' ";
        $result8 = mysqli_query($dbcon, $query8);
        
        $year = $row5['electionset_year'];
        $electionday = $row5['electionset_date'];
        $date = $row5['electionset_date'];
        $starttime = $row5['electionset_starttime'];
        $endtime = $row['electionset_endtime'];


        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
   
        $difdate = $electionday - $today;
        $diftime1 = $todaytime - $starttime;
        $diftime2 = $endtime - $todaytime;
        
        $date1= "$electionday"; //เวลาที่นำไปแปลง แสดงหน้าเลือกตั้ง
        
        
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                    include 'header.php';
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
             
            
            <br><br>
            
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">                
                <h1>การเลือกตั้งสภานักศึกษา <?php echo "$now_year"; ?> </h1><br>      
                <h><font size="4">การเลือกตั้งจะเริ่มภายในวันที่ <?php list($y,$m,$d)=explode('-',$date); echo$d.'/'.$m.'/'.$y; ?> เวลา <?php echo "$starttime" ?> น. ถึง <?php echo "$endtime"; ?> น. </font></h><br>
                <h><font size="4" color="red" >ลงคะแนนแล้วไม่สามารถแก้ไขได้ กรุณาตรวจสอบข้อมูลให้เรียบร้อยก่อนกดลงคะแนน</font></h>
                
                    <?php 
                          if($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime){                  
                                echo '<div class="uk-alert uk-alert-success"> <h2>ขณะนี้อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                          } else {                
                                echo '<div class="uk-alert uk-alert-warning"> <h2>ขณะนี้ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                          }
                          
                          if($result2->num_rows == 1){
                                echo '<div class="uk-alert uk-alert-fail"> <h2>กรุณาเลือกอีก 2 คน เบอร์ที่เลือกคือ</h2> </div>';
                          }else if ($result2->num_rows == 2) {
                                echo '<div class="uk-alert uk-alert-fail"> <h2>กรุณาเลือกอีก 1 คน เบอร์ที่เลือกคือ</h2> </div>';
                          }else if ($result2->num_rows >= 3) {
                                echo '<div class="uk-alert uk-alert-fail"> <h2>เลือกตั้งเรียบร้อยแล้ว เบอร์ที่เลือกคือ</h2> </div>';                   
                          }
                    ?>
                
                    <?php
                        while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                            if($row2[12] == 'normal'){
                               $row2[12] = 'แบบทั่วไป' ;
                            }
                    ?>
                <div class="uk-alert uk-alert-fail"> <h2>&emsp;&emsp;&emsp;เบอร์ <?php echo $row2[5];?> <?php echo $row2[6];?> <?php echo $row2[7];?> (<?php echo $row2[12];?>) <?php if($row2[12] == 'แบบคณะ'){echo " คณะ$row2[8]";} ?> </h2> </div>    
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                
                <?php
                        while ($row7 = mysqli_fetch_array($result7, MYSQLI_NUM)) {
                            if($row7[12] == 'fac'){
                               $row7[12] = 'แบบคณะ' ;
                            } 
                            
                            if($row7[13] == 1){
                                $row7[13] = 'รับรองสิทธิ' ;
                            }else{
                                $row7[13] = 'ไม่รับรองสิทธิ' ;
                            }                                                           
                    ?>
                <div class="uk-alert uk-alert-fail"> <h2>&emsp;&emsp;&emsp; <?php echo $row7[13];?> <?php echo $row7[6];?>  <?php echo $row7[7];?> <?php if($row7[12] == 'แบบคณะ'){echo " คณะ$row7[8]";} ?> (<?php echo $row7[12];?>) </h2> </div>    
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                <?PHP
                while ($row8 = mysqli_fetch_array($result8, MYSQLI_ASSOC)){
                    if($row8['sapa_fac'] == $s_faculty){
                        $check = 1;
                    }else{
                        $check = 0;
                    }
             
                }
                ?>
                        
                <h2>แบบทั่วไป</h2><br>
                <form align="center" method="GET" action="election_sapa.php">               
                    <?php if(!(($result2->num_rows >= 3) || ($result21->num_rows == 1))){  ?>
                    <button class="btn btn-success" type="submit" name="vote" value="1" style="width:250px;"  onclick="return confirm('ยืนยัน การลงคะแนนเสียง ');"><h3>ลงคะแนน</h3></button>
                    <?php }?>
                </form>
                <form align="center" method="GET" action="election_sapa_insert.php">
                    <input type="hidden" name="std_id" value="<?php echo $s_std_id ?>">
                    <input type="hidden" name="election_year" value="<?php echo $now_year?>" readonly>
                    
                    <?php if(!(($result2->num_rows >= 3)|| ($vote == 1) || ($result21->num_rows == 1))){  ?>
                    <button class="btn btn-danger" type="submit" name="voteno" value="1" style="width:250px;" onclick="return confirm('ยืนยัน ไม่ประสงค์ลงคะแนนเสียง ');"><h3>ไม่ประสงค์ลงคะแนน</h3></button>
                    <?php }?>
                </form><br>
                <table class="table">
                    <thead class="thead-dark">
                    <tr align="center">
                        <th scope="col">เบอร์</th>
                        <th scope="col">รูป</th>
                        <th scope="col">ชื่อ-นามสกุล</th>
                        <th scope="col">ชั้นปี</th>
                        <th scope="col">คณะ</th>
                        <?php if(!(($result2->num_rows >= 3) || ($vote != 1))){  ?>
                        <th scope="col">ลงคะแนน</th>
                        <?php }?>
                    </tr>
                    </thead>
                    <?php
                        while ($row3 = mysqli_fetch_array($result3, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr>  
                    <form method="GET" action="election_sapa_insert.php">
                        <td align="center"><h3><?php echo $row3[4];?></h3> <input type="hidden" name="sapa_num" value="<?php echo $row3[4];?>" readonly > </h2></td>
                        <td align="center"><img src="image_sapa/<?php echo $row3[9];?>" width="100px" height="100px"></td>      
                        <td align="center"><h3><?php echo $row3[6];?> <?php echo $row3[7];?> </h3><input type="hidden" name="sapa_name" value="<?php echo $row3[6];?>" readonly> <input type="hidden" name="sapa_lastname" value="<?php echo $row3[7];?>" readonly > <input type="hidden" name="type" value="<?php echo $row3[1];?>" readonly > </td>
                        <td align="center"><h3><?php echo $row3[8];?></h3><input type="hidden" name="std_year"value="<?php echo $row3[8];?>" readonly></td>
                        <td align="center"><h3><?php echo $row3[3];?></h3><input type="hidden" name="sapa_fac"value="<?php echo $row3[3];?>" readonly></td>
                        <?php if(!(($result2->num_rows >= 3) || ($vote != 1))){  ?>
                        <td align="center"><button class="btn btn-dark" type="submit" value="ลงคะแนน"  onclick="return confirm('ยืนยันการลงคะแนนเสียง เบอร์ <?php echo $i; ?> <?php echo $row3[5]; ?> <?php echo $row3[6]; ?> ');"><h3>ลงคะแนน</h3></button>
                        <?php }?>  
                    </form>    
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table> 
                <br>
                <h2>แบบสัดส่วนคณะ</h2><br>
                
                <table class="table">
                    <thead class="thead-dark">
                    <tr align="center">
                        <th scope="col">ลำดับ</th>
                        <th scope="col">รูป</th>
                        <th scope="col">ชื่อ-นามสกุล</th>
                        <th scope="col">ชั้นปี</th>
                        <th scope="col">คณะ</th>                        
                        <?php if(!($result6->num_rows == 1)){  ?>
                        <th scope="col">ลงคะแนน</th>
                        <?php }?>                       
                    </tr>
                    </thead>
                    <?php
                        while ($row4 = mysqli_fetch_array($result4, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr>
                        <form method="GET" action="election_sapa_insert.php">
                        <td align="center"><h4><?php echo $row4[4];?></h4> <input type="hidden" name="sapa_num" value="<?php echo $row4[4];?>" readonly > </td>
                        <td align="center"><img src="image_sapa/<?php echo $row4[9];?>" width="100px" height="100px"></td>      
                        <td align="center"><h4><?php echo $row4[6];?> <?php echo $row4[7];?> </h4><input type="hidden" name="sapa_name" value="<?php echo $row4[6];?>" readonly> <input type="hidden" name="sapa_lastname" value="<?php echo $row4[7];?>" readonly > <input type="hidden" name="type" value="<?php echo $row4[1];?>" readonly ></td>
                        <td align="center"><h4><?php echo $row4[8];?></h4><input type="hidden" name="std_year"value="<?php echo $row4[8];?>" readonly></td>
                        <td align="center"><h4><?php echo $row4[3];?></h4><input type="hidden" name="sapa_fac"value="<?php echo $row4[3];?>" readonly></td>
                        <?php if(!($result6->num_rows == 1)){  ?>
                        <td align="center"><button  class="btn btn-success" name="accept" type="submit"  value="1" style="width:150px;"  onclick="return confirm('ยืนยันการรับรองสิทธิ <?php echo $row4[5]; ?> <?php echo $row4[6]; ?> คณะ <?php echo $row4[3]; ?> ');"><h4>รับรองสิทธิ</h4></button>
                                           <button class="btn btn-danger" name="accept" type="submit" value="0" style="width:150px;"  onclick="return confirm('ยืนยันการไม่รับรองสิทธิ <?php echo $row4[5]; ?> <?php echo $row4[6]; ?> คณะ <?php echo $row4[3]; ?> ');"><h4>ไม่รับรองสิทธิ</h4></button>
                        <?php }?>                   
                        </form>
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table><br><hr>
            
                    <?php
                        include 'rs.php';
                    ?>
                </div>
                
                <?php
                            include 'right.php';                          
                ?>                
                </div>

            
              
                                         
            </div><!-- end grid -->                  
            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
<?php




