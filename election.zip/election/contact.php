<?php
        
        require 'connectdb.php';
        session_start();
        
        $year = $_GET['elect_year'];
        
        $query = "SELECT * FROM ongkan_team WHERE election_year = '2561' ";
        $result1 = mysqli_query($dbcon, $query);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
    </head>
    <body>
         <?php
                    include 'header.php';
            ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
             
           
            <br><br>
            
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
                    <article class="uk-article">

                        <h1 class="uk-article-title">
                            <a href="https://www.facebook.com/profile.php?id=100001373128866">ติดต่อ บังเด๊ะนะจ้ะ </a>
                        </h1>

                        

                        
                        
                        
                    </article>
                </div>
                
                <?php
                            include 'right.php';
                ?>                
                </div>

                    <?php
                        include 'rs.php';
                    ?>
                                         
            </div><!-- end grid -->                  
        
            
    </body>
    
</html>
