<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Register</title>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
    </head>
    <body>
        <?php
                    include 'header.php';
            ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
             
            
            <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4" style="font-coler: " >
                    
                    <form class="uk-form" action="register.php" method="post">
                    <fieldset data-uk-margin>
                       <legend>ลงทะเบียน</legend>
                       <input type="text" placeholder="User Name" name="username" required>
                       <input type="password" placeholder="Password" name="password" required>
                       <input type="submit" value="ลงทะเบียน" class="uk-button" > 
                    </fieldset>
                    </form>
                    
                </div>
                        
                <?php
                        include 'right.php';
                ?>

                </div>
                
                
            </div><!-- end grid -->                  
        
        </div>
        <?php
                 include 'rs.php';
        ?>
            
    </body>
</html>
