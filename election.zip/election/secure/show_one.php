<?php
        require 'connectdb.php';
        $q = "SELECT * FROM onedb INNER JOIN faculty_type ON onedb.one_faculty=faculty_type.faculty_id ";
        $result = mysqli_query($dbcon, $q);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>แสดงข้อมูลนักศึกษา</title>
        <style>
            a{background-color: #0076cb;}
            body{background-color: #FF7E00;}
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;
                background-color: lightslategray;
            }
        </style>
    </head>
    <body>
        <h2>ข้อมูลผู้สมัคเลือกตั้งแบบเดี่ยว</h2>
        <table style="width: 900px">
            <tr>
                <th>หมายเลขผู้สมัค</th>
                <th>ชื่อ</th>
                <th>นามสกุล</th>
                <th>รหัสนักศึกษา</th>
                <th>คณะ</th>
                <th>ชั้นปี</th>
                <th>แก้ไข</th>
                <th>ลบ</th>
            </tr>
            <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            ?>
            <tr>
                <td><?php echo $row['one_number']; ?></td>
                <td><?php echo $row['one_name']; ?></td>
                <td><?php echo $row['one_lastname']; ?></td>
                <td><?php echo $row['one_id']; ?></td>
                <td><?php echo $row['faculty_name']; ?></td>
                <td><?php echo $row['one_year']; ?></td>
                <td><a href="update_one.php?one_number=<?php echo $row['one_number']; ?>">แก้ไข</a></td>
                <td><a href="delete_one.php?one_number=<?php echo $row['one_number']; ?>">ลบ</a></td>
            </tr>
        <?php 
                }
                mysqli_free_result($result);
                mysqli_close($dbcon);
         ?>
    </table>
    </body>
</html>
