

<?php
        include 'session';
        session_start();
        require 'connectdb.php';
        
        $now_year = (date("Y")+543);
        
        $query = "SELECT * FROM ongkan_team  WHERE election_year = $now_year ORDER BY 'team_number'";
        $result = mysqli_query($dbcon, $query);
        
        $query1 = "SELECT * FROM electionset";
        $result1 = mysqli_query($dbcon, $query1);      
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);

        $query2 = "SELECT * FROM electionset_samo INNER JOIN election_type ON electionset_samo.electionset_name = election_type.election_id WHERE electionset_name = '003'AND electionset_year = $now_year ";
        $result2 = mysqli_query($dbcon, $query2);
        
        
        $query8 = "SELECT * FROM electionset_sapa" ;
        $result8 = mysqli_query($dbcon, $query8);
        $row4 = mysqli_fetch_array($result8, MYSQLI_ASSOC);
        
        $electionday2 = $row4['electionset_date'];
        $date2 = $row4['electionset_date'];
        $starttime2 = $row4['electionset_starttime'];
        $endtime2 = $row4['electionset_endtime'];
              
        $query5 = "SELECT COUNT(ongkan_num) FROM resault_ongkan" ;
        $result5 = mysqli_query($dbcon, $query5);
        
        $query6 = "SELECT * FROM sapa_candidate WHERE type ='normal'";
        $result6 = mysqli_query($dbcon, $query6);
        
        $query7 = "SELECT * FROM sapa_candidate WHERE type ='fac'";
        $result7 = mysqli_query($dbcon, $query7);
        
        $year1 = $row['electionset_year'];
        $year = $row['electionset_year'];
        $electionday = $row['electionset_date']; 
        $starttime = $row['electionset_starttime'];
        $endtime = $row['electionset_endtime'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
        
        $date1= "$electionday"; //เวลาที่นำไปแปลง แสดงหน้าเลือกตั้ง
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <br><br>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4" style="font-coler: " >
                
                <br><br><h>ยินดีต้อนรับ</h>
                <h>คุณ <?php echo $s_login_username; ?> อีเมล: <?php echo $s_login_email; ?></h>
        <hr>
        <h1>เมนูหลัก</h1>
        <form method="post">
            <button type="button" style="width:300px; font-size:20px" value="ข่าว" onClick="this.form.action='frm_news.php'; submit()"><h3>ข่าว</h3></button><br><br><br>
            <button type="button" style="width:300px; font-size:20px" value="การเลือกตั้ง" onClick="this.form.action='../select_election.php'; submit()"><h3>การเลือกตั้ง</h3></button><br><br><br>
            </from>
        <hr>
        <input type="button" style="width:100px; font-size:20px" value="ออกจากระบบ" onClick="this.form.action='logout.php'; submit()"> 
                    
                </div>
                <?php
                        include 'rs.php';
                    ?>
                <?php
                            include 'right.php';                          
                ?>                
                </div>
                                      
            </div><!-- end grid -->                            
    </body>
    <?php
    include 'footer.php';                          
    ?> 
</html>



