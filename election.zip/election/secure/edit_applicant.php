<!DOCTYPE html>
<html>
    <head>        
        <meta charset="UTF-8">
        <title>จัดการข้อมูลผู้สมัคเลือกตั้ง</title>
    </head>
    <h1>จัดการข้อมูลผู้สมัคเลือกตั้ง</h1>
    <body>
        <p>
            <a href="one_applicant_register.php">เพิ่มข้อมูลผู้สมัคเลือกตั้งแบบเดี่ยว</a>
            <br>
            <a href="team_applicant_register.php">เพิ่มข้อมูลผู้สมัคเลือกตั้งแบบทีม</a>
            <br><br><br>
            <a href="show_one.php">แสดงข้อมูลผู้สมัคแบบเดี่ยว</a>
            <br>
            <a href="show_team.php">แสดงข้อมูลผู้สมัคแบบทีม</a>
        </p>
    </body>
</html>
