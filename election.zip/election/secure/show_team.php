<?php
        require 'connectdb.php';
        $q = "SELECT * FROM teamdb INNER JOIN faculty_type ON teamdb.t_faculty=faculty_type.faculty_id ";        
        $result = mysqli_query($dbcon, $q);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>แสดงข้อมูลนักศึกษา</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <h2>ข้อมูลผู้สมัคเลือกตั้งแบบทีม</h2>
        <table style="width: 900px">
            <tr>
                <th>ชื่อพรรค</th>
                <th>เบอร์พรรค</th>
                <th>ชื่อ</th>
                <th>นามสกุล</th>
                <th>รหัสนักศึกษา</th>
                <th>คณะ</th>
                <th>ชั้นปี</th>
                <th>แก้ไข</th>
                <th>ลบ</th>
            </tr>
        <?php
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        ?>
        <tr>
            <td><?php echo $row['party_name']; ?></td>
            <td><?php echo $row['party_number']; ?></td>
            <td><?php echo $row['t_name']; ?></td>
            <td><?php echo $row['t_lastname']; ?></td>
            <td><?php echo $row['t_id']; ?></td>
            <td><?php echo $row['faculty_name']; ?></td>
            <td><?php echo $row['t_year']; ?></td>
            <td><a href="update_team.php?party_number=<?php echo $row['party_number']; ?>">แก้ไข</a></td>
            <td><a href="delete_team.php?party_number=<?php echo $row['party_number']; ?>">ลบ</a></td>
        </tr>
        <?php 
                }
                mysqli_free_result($result);
                mysqli_close($dbcon);
         ?>
    </table>
    </body>
</html>


