<?php
        require 'connectdb.php';
        
        $id = $_GET['id'];
        $type = $_GET['type'];
        $year = $_GET['year'];
        
        $q = "DELETE FROM sapa_candidate WHERE id='$id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_sapa_candidate_$type.php?elect_year=$year");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);
        
        

