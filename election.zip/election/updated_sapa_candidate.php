<?php
        require 'connectdb.php';
        
        $year = $_GET['year'];
        $type = $_GET['type'];
        $id = $_GET['id'];
        $std_num = $_GET['std_num'];
        $std_name = $_GET['std_name'];
        $std_lastname = $_GET['std_lastname'];
        $std_id = $_GET['std_id'];
        $sapa_fac = $_GET['sapa_fac'];
        $std_year = $_GET['std_year'];
       
     $q = "UPDATE sapa_candidate SET  std_id = '$std_id', std_name = '$std_name',  std_lastname = '$std_lastname', sapa_fac = '$sapa_fac', std_year = '$std_year', std_num = '$std_num' WHERE id = '$id' ";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
        header("Location: show_sapa_candidate_$type.php?elect_year=$year");
     } else {
        echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon); 
     }
     
     mysqli_close($dbcon);
 