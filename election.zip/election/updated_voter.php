<?php
        require 'connectdb.php';
        
        $studentv_name = $_POST['studentv_name'];
        $studentv_lastname = $_POST['studentv_lastname'];
        $studentv_id = $_POST['studentv_id'];
        $studentv_faculty = $_POST['t_faculty'];
        $studentv_year = $_POST['studentv_year'];
        
     $q = "UPDATE voterdb SET studentv_name='$studentv_name',studentv_lastname='$studentv_lastname',studentv_faculty='$studentv_faculty',studentv_year='$studentv_year' WHERE studentv_id='$studentv_id'";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
         echo "แก้ไขข้อมูลเรียบร้อยเเล้ว";
         echo "<hr>";
         echo "<a href='show_voter.php'>แสดงข้อมูล</a>";
     } else {
         echo "เกิดข้อผิดพลาด" . mysqli_errno($dbcon);    
     }
     
     mysqli_close($dbcon);
 