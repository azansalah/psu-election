<?php
        require 'connectdb.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ลงทะเบียนผู้ลงสมัคเลือกตั้งแบบทีม</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
      <h2>ลงทะเบียนผู้ลงสมัคเลือกตั้งแบบทีม</h2>
      <form action="team_register.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>กรอกข้อมูล</legend>
          <label>ชื่อพรรค: </label><input name="party_name" type="text" id="party_name" size="20" >
          <label>เบอร์พรรค: </label><input name="party_number" type="text" id="party_number" size="20" >
          <label>ชื่อ: </label><input name="t_name" type="text" id="t_name" size="20" >
          <label>สกุล: </label><input name="t_lastname" type="text" id="t_lastname" size="20">
          <label>รหัสนักศึกษา: </label><input name="t_id" type="text" id="t_id" size="20">
          
          <label>คณะ: </label>
          <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="t_faculty" id="t_faculty">
                  <option value="">---เลือกคณะ---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[0]'>$row[1]</option>";
                            }
                  ?>
                  </select>
                  
              <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="t_year" value="1" id="t_year_1">
           ปี1</label>          
           <label>
               <input type="radio" name="t_year" value="2" id="t_year_2">
           ปี2</label>
           <label>              
               <input type="radio" name="t_year" value="3" id="t_year_3">
           ปี3</label>
           <label>               
               <input type="radio" name="t_year" value="4" id="t_year_4">
           ปี4</label>
           <label>              
               <input type="radio" name="t_year" value="5" id="t_year_5">
           ปี5</label>
           <label>    
               <input type="radio" name="t_year" value="6" id="t_year_6">
           ปี6</label>
           
              <br>
              
              <input name="submit" type="submit" id="submit" value="บันทึก">
      </fieldset>        
      </form>
    </body>
</html>


