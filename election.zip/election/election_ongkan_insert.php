<?php
        include 'session.php';
        require 'connectdb.php';
                
        $ongkan_num = $_GET['ongkan_num'];
        $std_id = $_GET['std_id'];
        $election_year = $_GET['election_year'];
        $voteno = $_GET['voteno'];
               
        $query1 = "SELECT * FROM electionset";
        $result1 = mysqli_query($dbcon, $query1);
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        
        $query2 = "SELECT * FROM resault_ongkan WHERE std_id = $s_std_id";
        $result2 = mysqli_query($dbcon, $query2);       
   
        $electionday = $row['electionset_date']; 
        $starttime = $row['electionset_starttime'];
        $endtime = $row['electionset_endtime'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
        
        if($voteno == 1){
            $query3 = "INSERT INTO resault_ongkan (std_id, name, lastname, faculty, ongkan_num, date, time, election_year, vote_no) VALUES ('$std_id','$s_name', '$s_lastname', '$s_faculty', '0', '$today', '$todaytime', '$election_year', '$voteno') ";
            $result3 = mysqli_query($dbcon, $query3);
                
                if($result3){
                    header("Location: election_warning.php?code=32");
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }
                 
        } 
        
        
        else if($result2->num_rows == 1){
            header("Location: election_warning.php?code=1");
        }
        else if(!($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime)) {
            header("Location: election_warning.php?code=2");
        }
        else{        
            $query = "INSERT INTO resault_ongkan (std_id, name, lastname, faculty, ongkan_num, date, time, election_year) VALUES ('$std_id','$s_name', '$s_lastname', '$s_faculty', '$ongkan_num', '$today', '$todaytime', '$election_year') ";
            $result = mysqli_query($dbcon, $query);
                
                if($result){
                    header("Location: election_warning.php?code=3?$result2->num_rows");
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }
                 
        } 
                
    mysqli_close($dbcon);    
                    
