<?php
        require 'connectdb.php';
        
        $party_name = $_POST['party_name'];
        $party_number = $_POST['party_number'];
        $t_name	= $_POST['t_name'];
        $t_lastname = $_POST['t_lastname'];
        $t_id = $_POST['t_id'];
        $t_faculty = $_POST['t_faculty'];
        $t_year = $_POST['t_year'];
        
     $q = "UPDATE teamdb SET party_name='$party_name',t_name='$t_name',t_lastname='$t_lastname',t_id='$t_id',t_faculty='$t_faculty',t_year='$t_year' WHERE party_number='$party_number'";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
         echo "แก้ไขข้อมูลเรียบร้อยเเล้ว";
         echo "<hr>";
         echo "<a href='show_team.php'>แสดงข้อมูล</a>";
     } else {
         echo "เกิดข้อผิดพลาด" . mysqli_errno($dbcon);    
     }
     
     mysqli_close($dbcon);
 