<?php

        require 'connectdb.php';
        $type = $_POST['type'];
        $year = $_POST['year'];
        $sapa_fac = $_POST['sapa_fac'];
        $std_id = $_POST['std_id'];
        $std_num = $_POST['std_num'];
        $std_name = $_POST['std_name'];
        $std_lastname = $_POST['std_lastname'];
        $std_year = $_POST['std_year'];
        
        //upload image
        $ext = pathinfo(basename($_FILES['std_image']['name']), PATHINFO_EXTENSION);
        $new_image_name = 'img_'.uniqid().".".$ext;
        $image_path = "image_sapa/";
        $upload_path =$image_path.$new_image_name;
        //uploading
        $success = move_uploaded_file($_FILES['std_image']['tmp_name'], $upload_path);
        if($success==FALSE) {
            echo 'ไม่สามารถอัพโหลดรูปภาพได้';
            exit();
        }
        
        $std_image = $new_image_name;
        
        $query = "INSERT INTO sapa_candidate (type, year, sapa_fac, std_id, std_name, std_lastname, std_year, std_image, std_num ) VALUES ('$type', '$year', '$sapa_fac', '$std_id', '$std_name', '$std_lastname', '$std_year', '$std_image', '$std_num')";
        
        $result = mysqli_query($dbcon, $query);
        
        if ($result) {
            header("Location: show_sapa_candidate_$type.php?elect_year=$year");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);


