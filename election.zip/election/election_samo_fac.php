<?php
        include 'session.php';
        require 'connectdb.php';
        session_start();
        
        $now_year = (date("Y")+543);
        
        $samo_num = $_GET['samo_num'];
        $samo_name = $_GET['samo_name'];
        $samo_fac = $_GET['samo_fac'];
        
        if($samo_fac == "วิทยาศาสตร์"){
            $samo_fac_check = "sc";
        }
        if($samo_fac == "วิศวกรรมศาสตร์"){
            $samo_fac_check = "en";
        }
        if($samo_fac == "ทรัพยากรธรรมชาติ"){
            $samo_fac_check = "rn";
        }
        if($samo_fac == "อุตสาหกรรมเกษตร"){
            $samo_fac_check = "agro";
        }
        if($samo_fac == "การจัดการสิ่งแวดล้อม"){
            $samo_fac_check = "em";
        }
        if($samo_fac == "แพทยศาสตร์"){
            $samo_fac_check = "md";
        }
        if($samo_fac == "พยาบาลศาสตร์"){
            $samo_fac_check = "nu";
        }
        if($samo_fac == "วิทยาลัยนานาชาติ"){
            $samo_fac_check = "uic";
        }
        if($samo_fac == "ทันตแพทยศาสตร์"){
            $samo_fac_check = "dt";
        }
        if($samo_fac == "เภสัชศาสตร์"){
            $samo_fac_check = "ps";
        }
        if($samo_fac == "วิทยาการจัดการ"){
            $samo_fac_check = "ms";
        }
        if($samo_fac == "ศิลปศาสตร์"){
            $samo_fac_check = "la";
        }
        if($samo_fac == "เศรษฐศาสตร์"){
            $samo_fac_check = "econ";
        }
        if($samo_fac == "นิติศาสตร์"){
            $samo_fac_check = "law";
        }
        if($samo_fac == "การแพทย์แผนไทย"){
            $samo_fac_check = "tm";
        }
        if($samo_fac == "เทคนิคการแพทย์"){
            $samo_fac_check = "md";
        }
        if($samo_fac == "สัตวแพทยศาสตร์"){
            $samo_fac_check = "vs";
        }
        
        
        
        $query = "SELECT * FROM samo_team  WHERE faculty = '$samo_fac'";  
        $result = mysqli_query($dbcon, $query);
        
        
        $query1 = "SELECT * FROM electionset_samo WHERE electionset_faculty = '$samo_fac' ";
        $result1 = mysqli_query($dbcon, $query1);
        $row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        
        $query2 = "SELECT * FROM resault_samo_$samo_fac_check WHERE std_id = $s_std_id";
        $result2 = mysqli_query($dbcon, $query2);       
        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);
        $voteno = $row2['vote_no'];

        $year = $row1['electionset_year'];
        $electionday = $row1['electionset_date']; 
        $starttime = $row1['electionset_starttime'];
        $endtime = $row1['electionset_endtime'];
        $std_id = $row2['std_id'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
       
        $difdate = $electionday - $today;
        $diftime1 = $todaytime - $starttime;
        $diftime2 = $endtime - $todaytime;
        
        $date1= "$electionday"; //เวลาที่นำไปแปลง แสดงหน้าเลือกตั้ง
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
         <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <?php
                    include 'header.php';                 
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom ">
            <br><br>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
            <h1>สโมสรนักศึกษา คณะ<?php echo $samo_fac ?> </h1><br>
            
            <h><font size="4">เลือกตั้งภายในวันที่ <?php list($y,$m,$d)=explode('-',$date1); echo$d.'/'.$m.'/'.$y; ?> เวลา <?php echo "$starttime" ?> น. ถึง <?php echo "$endtime"; ?> น. </font></h><br>
                <h><font size="4" color="red" >ลงคะแนนแล้วไม่สามารถแก้ไขได้ กรุณาตรวจสอบข้อมูลให้เรียบร้อยก่อนกดลงคะแนน</font></h>
                &emsp;&emsp;
                    
                <?php 
                    if($samo_fac == $s_faculty){
                            
                    if($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime){                  
                            echo '<div class="uk-alert uk-alert-success"> <h2>ขณะนี้อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                    } else {                
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ขณะนี้ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                    }
                                       
                      if($result2->num_rows == 1){
                            if($voteno == 0){
                                echo '<div class="uk-alert uk-alert-success"> <h2>คุณได้ลงคะแนนเสียงเรียบร้อยแล้ว</h2> </div>';
                            }else{
                                echo '<div class="uk-alert uk-alert-success"> <h2>คุณได้ลงคะแนนเสียงเรียบร้อยแล้ว (ไม่ประสงค์ลงคะแนน)</h2> </div>';    
                            }
                    } else {
                            echo '<div class="uk-alert uk-alert-fail"> <h2>คุณยังไม่ได้ลงคะแนนเสียง</h2> </div>';  
                            
                    } 
                            echo "<br>";
                          
                    } else {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>กรุณาตรวจสอบคณะของคุณให้ถูกต้อง</h2> </div>';
                    }       
                ?>
            
            <table class="table">
                <thead class="thead-dark">
                <tr align="center" >
                    <th scope="col">โลโก้พรรค</th>
                    <th scope="col">หมายเลขพรรค</th>
                    <th scope="col">ชื่อพรรค</th>
                    <th scope="col">รายละเอียด</th>
                    <?php if(!($result2->num_rows == 1)AND($samo_fac == $s_faculty)){  ?>
                    <th scope="col">ลงคะแนน</th>
                    <?php }?>
                </tr>
                </thead>
                <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                ?>
                <tbody>
                <tr align="center">
                        <td align="center"><img src="image_samo/logo/<?php echo $row[4];?>" width="100px" height="100px"></td>
                        <form method="GET" action="election_samo_insert.php">
                        <input type="hidden" name="std_id" value="<?php echo $s_std_id ?>">
                        <input type="hidden" name="samo_fac" value="<?php echo $samo_fac ?>">
                        <td align="center"><h2><?php echo $row[0];?></h2><input type="hidden" name="samo_num" value="<?php echo $row[0];?>" readonly></td>
                        <td align="center"><h2><?php echo $row[1];?></h2><input type="hidden" name="samo_name"value="<?php echo $row[1];?>" readonly></td>
                        <input type="hidden" name="election_year" value="<?php echo $row[3];?>" readonly>
                        <td align="center"><button class="btn btn-dark" type="submit" value="สมาชิคพรรค" onClick="this.form.action='show_electionsamo_candi_user.php'; submit()"><h2>สมาชิคพรรค</h2></button></td>
                        <?php if(!($result2->num_rows == 1)AND($samo_fac == $s_faculty)){  ?>
                        <td align="center"><button class="btn btn-dark" type="submit" value="ลงคะแนน"  onclick="return confirm('ยืนยันการลงคะแนนเสียง เบอร์ <?php echo $row[0]; ?> พรรค<?php echo $row[1]; ?>');"><h2>ลงคะแนน</h2></button>
                        <?php }?>
                        </form>
                    </tr>
                </tbody>
                <?php 
                    }
                    mysqli_free_result($result);
                    mysqli_close($dbcon);
                ?>
            </table>
                </form>              
                <form align="center" method="GET" action="election_samo_insert.php">
                    <input type="hidden" name="std_id" value="<?php echo $s_std_id ?>">
                    <input type="hidden" name="election_year" value="<?php echo $now_year?>" readonly>
                    <input type="hidden" name="samo_fac" value="<?php echo $samo_fac ?>">
                    <?php if(!($result2->num_rows == 1)){  ?>
                    <button class="btn btn-danger" type="submit" name="voteno" value="1"  onclick="return confirm('ยืนยัน ไม่ประสงค์ลงคะแนนเสียง ');"><h3>ไม่ประสงค์ลงคะแนน</h3></button>
                    <?php }?>
                </form>              
            </div>
                <?php
                        include 'rs.php';
                    ?>
                <?php
                            include 'right.php';                          
                ?>            
             </div>                        
            </div><!-- end grid -->                  
        
            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
