<?php

        require 'connectdb.php';
        
        $electionset_name = 1;
        $year = $_POST['year'];
        $date = $_POST['date'];
        $starttime = $_POST['starttime'];
        $endtime = $_POST['endtime'];
        
        $q = "INSERT INTO electionset (electionset_name, electionset_date, electionset_starttime, electionset_endtime, electionset_year) VALUES ('$electionset_name', '$date', '$starttime', '$endtime', '$year')";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            header("Location: create_election_ongkan_show.php");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);

