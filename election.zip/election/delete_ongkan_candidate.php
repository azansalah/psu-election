<?php
        require 'connectdb.php';
        
        $id = $_GET['id'];
        $ongkan_num = $_GET['ongkan_num'];
        $ongkan_name = $_GET['ongkan_name'];
        
        $q = "DELETE FROM ongkan_candidate WHERE id='$id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_electionongkan.php?ongkan_num=$ongkan_num&ongkan_name=$ongkan_name");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);
        
        

