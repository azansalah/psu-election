<?php

        include 'frm_insert_sapa_team';
        require 'connectdb.php';
        
        $team_number = $_POST['team_number'];
        $team_name = $_POST['team_name'];
        $faculty = $_POST['faculty'];
        
        $q = "INSERT INTO sapa_team (team_number, team_name, faculty) VALUES ('$team_number','$team_name', '$faculty')";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            echo "เพิ่มข้อมูลเรียบร้อยแล้ว" ;
            echo "<hr>";
           
            echo "<a href='show_sapa_team.php'>แสดงข้อมูล</a>";
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);