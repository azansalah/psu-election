<?php
        require 'connectdb.php';
        
        $faculty_search = $_GET['sapa_faculty'];
        $teamname_search = $_GET['team_name'];
        
        if($faculty_search == "" AND $teamname_search == ""){
            $query = "SELECT * FROM sapa_candidate INNER JOIN position_type ON sapa_candidate.std_pos = position_type.position_id ORDER BY sapa_fac,sapa_num,sapa_name,std_pos";
        }else if($faculty_search == "" AND $teamname_search != ""){
            $query = "SELECT * FROM sapa_candidate INNER JOIN position_type ON sapa_candidate.std_pos = position_type.position_id WHERE sapa_name = '$teamname_search' ORDER BY sapa_fac,sapa_num,sapa_name,std_pos";
        }else if($faculty_search != "" AND $teamname_search == ""){
            $query = "SELECT * FROM sapa_candidate INNER JOIN position_type ON sapa_candidate.std_pos = position_type.position_id WHERE sapa_fac = '$faculty_search' ORDER BY sapa_fac,sapa_num,sapa_name,std_pos";
        }
        else{
            $query = "SELECT * FROM sapa_candidate INNER JOIN position_type ON sapa_candidate.std_pos = position_type.position_id WHERE sapa_fac = '$faculty_search' AND sapa_name = '$teamname_search' ORDER BY sapa_fac,sapa_num,sapa_name,std_pos";            
        }
        $result = mysqli_query($dbcon, $query);


?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>แสดงข้อมูลนักศึกษา</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <h2>ข้อมูลผู้สมัคเลือกตั้งสภานักศึกษา ทั้งหมด</h2>
        
        <form method="GET" action="show_electionsapa.php">
            
        <label>เลือกคณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result2 = mysqli_query($dbcon, $q);
              ?>
              <select name="sapa_faculty" id="sapa_faculty">
                  <option value="">---ทั้งหมด---</option>
                  <?php
                            while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                                echo "<option value='$row2[1]'>$row2[1]</option>";
                            }
                  ?>
              </select><br>
        <label>ชื่อพรรค: </label>
            <input type="text" name="team_name">
            <br>
        <input type="submit" value="แสดง"><br><br>
            
        </form>
        
        <a href='show_sapa_team.php'>กลับไปยังเพิ่มสมาชิก</a>
        <br><br>
        <table style="width: 900px">
            <tr>
                <th>ลำดับ</th>
                <th>เบอร์</th>
                <th>ชื่อพรรค</th>
                <th>ชื่อ-นามสกุล</th>
                <th>รหัสนักศึกษา</th>
                <th>คณะ</th>
                <th>ชั้นปี</th>
                <th>ตำแหน่ง</th>
                
                
            </tr>
            <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            ?>
            <tr>
                <td><?php echo $row['std_pos']; ?></td>
                <td><?php echo $row['sapa_num']; ?></td>
                <td><?php echo $row['sapa_name']; ?></td>
                <td><?php echo $row['std_name']; ?></td>
                <td><?php echo $row['std_id']; ?></td>
                <td><?php echo $row['sapa_fac']; ?></td>
                <td><?php echo $row['std_year']; ?></td>
                <td><?php echo $row['position_name']; ?></td>
                <!--<td><a href="update_one.php?one_number=<?php echo $row['one_number']; ?>">แก้ไข</a></td>
                <td><a href="delete_one.php?one_number=<?php echo $row['one_number']; ?>">ลบ</a></td>-->
            </tr>
        <?php 
                }
                mysqli_free_result($result);
                mysqli_close($dbcon);
         ?>
    </table>
    </body>
</html>


