<?php
        include 'session';
        require 'connectdb.php';
        session_start();
        
        $ongkan_num = $_GET['ongkan_num'];
        $ongkan_name = $_GET['ongkan_name'];
        
      
        $query = "SELECT * FROM ongkan_candidate INNER JOIN position_type ON ongkan_candidate.std_pos = position_type.position_id WHERE ongkan_num = '$ongkan_num' AND ongkan_name = '$ongkan_name' ORDER BY ongkan_name,ongkan_num,std_pos";            
        
        $result = mysqli_query($dbcon, $query);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
         <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <?php
                    include 'header.php';
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom ">  
            <br><br>
            <h1>ข้อมูลผู้สมัคเลือกตั้งองค์การบริหาร องค์การนักศึกษา </h1>
            <h1>เบอร์ <?php echo "$ongkan_num"; ?> พรรค <?php echo "$ongkan_name"; ?></h1><br>
            <table class="table">
                <thead class="thead-dark">
                <tr align="center">
                    <th scope="col">ลำดับ</th>
                    <th scope="col">รูป</th>
                    <th scope="col">เบอร์</th>
                    <th scope="col">ชื่อพรรค</th>
                    <th scope="col">ชื่อ-นามสกุล</th>
                    <th scope="col">รหัสนักศึกษา</th>
                    <th scope="col">คณะ</th>
                    <th scope="col">ชั้นปี</th>
                    <th scope="col">ตำแหน่ง</th>            
                </tr>
                </thead>
                <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                ?>
                <tbody>
                <tr align="center" >
                    <td align="center"><h3><?php echo $row['std_pos'];?></h3></td>
                    <td align="center"><img src="image_ongkan/candidate/<?php echo $row['std_image'];?>" width="100px" height="100px"></td>
                    <td align="center"><h3><?php echo $row['ongkan_num'];?></h3></td>
                    <td align="center"><h3><?php echo $row['ongkan_name'];?></h3></td> 
                    <td align="center"><h3><?php echo $row['std_name'];?></h3></td>
                    <td align="center"><h3><?php echo $row['std_id'];?></h3></td>
                    <td align="center"><h3><?php echo $row['ongkan_fac'];?></h3></td>
                    <td align="center"><h3><?php echo $row['std_year'];?></h3></td>
                    <td align="center"><h3><?php echo $row['position_name'];?></h3></td>
                </tr>
                </tbody>
                <?php 
                    }
                    mysqli_free_result($result);
                    mysqli_close($dbcon);
                ?>
            </table>
                                     
            </div><!-- end grid -->                  
        
            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
