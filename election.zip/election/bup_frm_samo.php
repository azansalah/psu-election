<?php
        require 'connectdb.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>ผู้ลงเลือกตั้งสโมสรนักศึกษา</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
      <h2>ผู้ลงเลือกตั้งสโมสรนักศึกษา</h2>
      <form action="insert_electionsamo.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>กรอกข้อมูล</legend>
          
          <label>เบอร์พรรค: </label><input name="team_number" type="text" id="team_number" size="20" >
          <label>ชื่อพรรค: </label><input name="team_name" type="text" id="team_name" size="20" >
          
          <label>ชื่อ-สกุล: </label><input name="samo_name" type="text" id="samo_name" size="20" >     
          <label>รหัสนักศึกษา: </label><input name="samo_id" type="number" id="samo_id" size="20">
          <label>เลือกคณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
              ?>
              <select name="samo_faculty" id="samo_faculty">
                  <option value="">---เลือกคณะ---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[0]'>$row[1]</option>";
                            }
                  ?>
              </select>
          <br><br>
           <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="year" value="1" id="year_1">
           ปี1</label>          
           <label>
               <input type="radio" name="year" value="2" id="year_2">
           ปี2</label>
           <label>              
               <input type="radio" name="year" value="3" id="year_3">
           ปี3</label>
           <label>               
               <input type="radio" name="year" value="4" id="year_4">
           ปี4</label>
           <label>              
               <input type="radio" name="year" value="5" id="year_5">
           ปี5</label>
           <label>    
               <input type="radio" name="year" value="6" id="year_6">
           ปี6</label>
           <br>
           
           <label>ตำแหน่ง: </label>
              <?php
                $q = "SELECT * FROM position_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="position" id="posision">
                  <option value="">---เลือกตำแหน่ง---</option>
                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                echo "<option value='$row[0]'>$row[1]</option>";
                            }
                  ?>
              </select>
           <br><br>
              
              <input name="submit" type="submit" id="submit" value="บันทึก">
      </fieldset>        
      </form>
    </body>
</html>









