<?php

        include 'frm_insert_samo_team';
        require 'connectdb.php';
        
        $team_number = $_POST['team_number'];
        $team_name = $_POST['team_name'];
        $faculty = $_POST['elect_fac'];
        $election_year = $_POST['elect_year'];
        $date = $_POST['elect_date'];
        $starttime = $_POST['elect_starttime'];
        $endtime = $_POST['elect_endtime'];
        
        //upload image
        $ext = pathinfo(basename($_FILES['team_image']['name']), PATHINFO_EXTENSION);
        $new_image_name = 'img_'.uniqid().".".$ext;
        $image_path = "image_samo/logo/";
        $upload_path =$image_path.$new_image_name;
        //uploading
        $success = move_uploaded_file($_FILES['team_image']['tmp_name'], $upload_path);
        if($success==FALSE) {
            echo 'ไม่สามารถอัพโหลดรูปภาพได้';
            exit();
        }
        
        $team_image = $new_image_name;
        
        $q = "INSERT INTO samo_team (team_number, team_name, faculty, election_year, team_image) VALUES ('$team_number','$team_name', '$faculty', '$election_year', '$team_image')";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            header("Location: show_samo_team.php?elect_name=สโมสรนักศึกษา&elect_fac=$faculty&elect_year=$election_year&elect_date=$date&elect_starttime=$starttime&elect_endtime=$endtime");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);