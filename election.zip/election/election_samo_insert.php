<?php
        include 'session.php';
        require 'connectdb.php';
                
        $samo_num = $_GET['samo_num'];
        $samo_fac = $_GET['samo_fac'];
        $std_id = $_GET['std_id'];
        $election_year = $_GET['election_year'];
        $voteno = $_GET['voteno'];
        
        if($samo_fac == "วิทยาศาสตร์"){
            $samo_fac_check = "sc";
        }
        if($samo_fac == "วิศวกรรมศาสตร์"){
            $samo_fac_check = "en";
        }
        if($samo_fac == "ทรัพยากรธรรมชาติ"){
            $samo_fac_check = "rn";
        }
        if($samo_fac == "อุตสาหกรรมเกษตร"){
            $samo_fac_check = "agro";
        }
        if($samo_fac == "การจัดการสิ่งแวดล้อม"){
            $samo_fac_check = "em";
        }
        if($samo_fac == "แพทยศาสตร์"){
            $samo_fac_check = "md";
        }
        if($samo_fac == "พยาบาลศาสตร์"){
            $samo_fac_check = "nu";
        }
        if($samo_fac == "วิทยาลัยนานาชาติ"){
            $samo_fac_check = "uic";
        }
        if($samo_fac == "ทันตแพทยศาสตร์"){
            $samo_fac_check = "dt";
        }
        if($samo_fac == "เภสัชศาสตร์"){
            $samo_fac_check = "ps";
        }
        if($samo_fac == "วิทยาการจัดการ"){
            $samo_fac_check = "ms";
        }
        if($samo_fac == "ศิลปศาสตร์"){
            $samo_fac_check = "la";
        }
        if($samo_fac == "เศรษฐศาสตร์"){
            $samo_fac_check = "econ";
        }
        if($samo_fac == "นิติศาสตร์"){
            $samo_fac_check = "law";
        }
        if($samo_fac == "การแพทย์แผนไทย"){
            $samo_fac_check = "tm";
        }
        if($samo_fac == "เทคนิคการแพทย์"){
            $samo_fac_check = "md";
        }
        if($samo_fac == "สัตวแพทยศาสตร์"){
            $samo_fac_check = "vs";
        }
        
                
        
        $query1 = "SELECT * FROM electionset_samo WHERE electionset_faculty = '$samo_fac' ";
        $result1 = mysqli_query($dbcon, $query1);
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        
        $query2 = "SELECT * FROM resault_samo_$samo_fac_check WHERE std_id = $s_std_id";
        $result2 = mysqli_query($dbcon, $query2);       
   

        $electionday = $row['electionset_date']; 
        $starttime = $row['electionset_starttime'];
        $endtime = $row['electionset_endtime'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
        
        
        
        if($samo_fac == $s_faculty){
            
        if($voteno == 1){
            $query3 = "INSERT INTO resault_samo_$samo_fac_check (std_id, name, lastname, samo_num, date, time, election_year, vote_no) VALUES ('$std_id', '$s_name', '$s_lastname', '0', '$today', '$todaytime', '$election_year', '$voteno') ";
            $result3 = mysqli_query($dbcon, $query3);
                
                if($result3){
                    header("Location: election_warning.php?code=62"); 
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }       
        }
        else if($result2->num_rows == 1){
            header("Location: election_warning.php?code=4");
        }
        else if(!($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime)) {
            header("Location: election_warning.php?code=5");
        }
        else{        
            $query = "INSERT INTO resault_samo_$samo_fac_check (std_id, name, lastname, samo_num, date, time, election_year) VALUES ('$std_id', '$s_name', '$s_lastname', '$samo_num', '$today', '$todaytime', '$election_year') ";
            $result = mysqli_query($dbcon, $query);
                
                if($result){
                    header("Location: election_warning.php?code=6?$result2->num_rows");
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }               
            } 
        }else{
            header("Location: election_warning.php?code=7");
        }        
    mysqli_close($dbcon);    
                    
