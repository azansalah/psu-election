<?php 
        include 'session';
        require 'connectdb.php';
        session_start();
        $user = $_SESSION['login_username'];
        
        $query = "SELECT * FROM tblogin WHERE login_username ='$user'";
        $result1 = mysqli_query($dbcon, $query);
?>
<div class="uk-width-medium-1-4">
                    <?php
                        if (isset($_SESSION['is_member']))
                            while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)){
                    ?>
                    <div style="font-size: large" >
                        <p>
                            ยินดีต้อนรับคุณ <?php echo $row1[6];?> <?php echo $row1[7];?> 
                        </p>
                        <p>
                            คณะ <?php echo $row1[8];?> 
                        </p>
                        <p>
                            รหัส <?php echo $row1[10];?>
                        </p>
                        
                    </div>
                    <?php }?><br>
    
                    <div class="uk-panel">
                        <h4>การเลือกตั้ง</h4>
                        <ul class="uk-list uk-list-line" style="font-size: medium">
                            <li><a href="election_ongkan.php">องค์การบริหาร องการนักศึกษา</a></li>
                            <li><a href="election_sapa.php">สภานักศึกษา</a></li>
                            <li><a href="election_samo.php">สโมสรนักศึกษา</a></li>               
                        </ul>
                    </div>

</div>