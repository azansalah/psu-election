<?php
        include 'session';
        session_start();
        require 'connectdb.php';
        
        $now_year = (date("Y")+543);
        
        $query = "SELECT * FROM ongkan_team  WHERE election_year = $now_year ORDER BY 'team_number'";
        $result = mysqli_query($dbcon, $query);
       
        
        $query1 = "SELECT * FROM electionset";
        $result1 = mysqli_query($dbcon, $query1);      
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);

        $query2 = "SELECT * FROM electionset_samo INNER JOIN election_type ON electionset_samo.electionset_name = election_type.election_id WHERE electionset_name = '003'AND electionset_year = $now_year ";
        $result2 = mysqli_query($dbcon, $query2);
        
        
        $query8 = "SELECT * FROM electionset_sapa" ;
        $result8 = mysqli_query($dbcon, $query8);
        $row4 = mysqli_fetch_array($result8, MYSQLI_ASSOC);
        
        $electionday2 = $row4['electionset_date'];
        $date2 = $row4['electionset_date'];
        $starttime2 = $row4['electionset_starttime'];
        $endtime2 = $row4['electionset_endtime'];
              
        $query5 = "SELECT COUNT(ongkan_num) FROM resault_ongkan" ;
        $result5 = mysqli_query($dbcon, $query5);
        
        $query6 = "SELECT * FROM sapa_candidate WHERE type ='normal'";
        $result6 = mysqli_query($dbcon, $query6);
        
        $query7 = "SELECT * FROM sapa_candidate WHERE type ='fac'";
        $result7 = mysqli_query($dbcon, $query7);
        
        $year1 = $row['electionset_year'];
        $year = $row['electionset_year'];
        $electionday = $row['electionset_date']; 
        $starttime = $row['electionset_starttime'];
        $endtime = $row['electionset_endtime'];
        
        

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
        
        $date1= "$electionday"; //เวลาที่นำไปแปลง แสดงหน้าเลือกตั้ง
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                    include 'header.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <br><br>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4" style="font-coler: " >
                <h1>องค์การบริหาร องค์การนักศึกษา <?php echo "$year"; ?></h1>
                <h><font size="4">การเลือกตั้งจะเริ่มภายในวันที่ <?php list($y,$m,$d)=explode('-',$date1); echo$d.'/'.$m.'/'.$y; ?> เวลา <?php echo "$starttime" ?> น. ถึง <?php echo "$endtime"; ?> น. </font></h><br>
                <h><font size="4">ณ อาคารกิจกรรมนักศึกษา </font></h><br>
                <?php if($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime){                  
                            echo '<div class="uk-alert uk-alert-success"> <h2>ขณะนี้อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                      } else {                
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ขณะนี้ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                      }?>
                
                <table class="table"> 
                    <thead class="thead-dark" >
                    <tr align="center">
                        <th scope="col">โลโก้พรรค</th>
                        <th scope="col">หมายเลขพรรค</th>
                        <th scope="col">ชื่อพรรค</th>
                        <th scope="col">รายละเอียด</th>
                    </tr>
                    </thead>
                    <?php
                        while ($row1 = mysqli_fetch_array($result, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr style="text-align: center">
                        <td><img src="image_ongkan/logo/<?php echo $row1[4];?>" width="100px" height="100px"></td>
                        <form method="GET" action="frm_ongkan_candidate.php">                  
                        <td><h2><?php echo $row1[0];?></h2><input type="hidden" name="ongkan_num" value="<?php echo $row1[0];?>" readonly></td>
                        <td><h2><?php echo $row1[1];?></h2><input type="hidden" name="ongkan_name"value="<?php echo $row1[1];?>" readonly></td>
                        <td><button class="btn btn-dark" type="submit" value="สมาชิคพรรค" onClick="this.form.action='show_electionongkan_user.php'; submit()"><h3>สมาชิคพรรค</h3></button></td>
                        </form>
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table><br><br><hr>
                
                <br><h1>สภานักศึกษา <?php echo "$year"; ?> </h1><br>       
                <h><font size="4">การเลือกตั้งจะเริ่มภายในวันที่ <?php list($y,$m,$d)=explode('-',$date2); echo$d.'/'.$m.'/'.$y; ?> เวลา <?php echo "$starttime2" ?> น. ถึง <?php echo "$endtime2"; ?> น. </font></h><br>
                <h><font size="4">ณ อาคารกิจกรรมนักศึกษา </font></h><br>
                <?php if($today == $electionday2 and $todaytime >= $starttime2 and $todaytime <= $endtime2){                  
                            echo '<div class="uk-alert uk-alert-success"> <h2>ขณะนี้อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                      } else {                
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ขณะนี้ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                      }?>
                <h2>แบบทั่วไป</h2><br>
                <table class="table">
                    <thead class="thead-dark" >
                    <tr align="center">
                        <th scope="col">เบอร์</th>
                        <th scope="col">รูป</th>
                        <th scope="col">ชื่อ-นามสกุล</th>
                        <th scope="col">ชั้นปี</th>
                        <th scope="col">คณะ</th>
                    </tr>
                    </thead>
                    <?php
                        while ($row3 = mysqli_fetch_array($result6, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr>
                        <td align="center"><h2><?php echo $row3[4];?></h2></td>
                        <td align="center"><img src="image_sapa/<?php echo $row3[9];?>" width="100px" height="100px"></td>      
                        <td align="center"><h2><?php echo $row3[6];?> <?php echo $row3[7];?> </h2><input type="hidden" name="ongkan_num" value="<?php echo $row3[0];?>" readonly></td>
                        <td align="center"><h2><?php echo $row3[8];?></h2><input type="hidden" name="std_year"value="<?php echo $row3[7];?>" readonly></td>
                        <td align="center"><h2><?php echo $row3[3];?></h2><input type="hidden" name="sapa_fac"value="<?php echo $row3[3];?>" readonly></td>
                        
                        </form>
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table><br>
                <h2>แบบสัดส่วนคณะ</h2><br>
                
                <table class="table">
                    <thead class="thead-dark">
                    <tr align="center">
                        <th scope="col">ลำดับ</th>
                        <th scope="col">รูป</th>
                        <th scope="col">ชื่อ-นามสกุล</th>
                        <th scope="col">ชั้นปี</th>
                        <th scope="col">คณะ</th>
                    </tr>
                    </thead>
                    <?php
                        while ($row4 = mysqli_fetch_array($result7, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr>
                        <td align="center"><h2><?php echo $row4[4];?></h2></td>
                        <td align="center"><img src="image_sapa/<?php echo $row4[9];?>" width="100px" height="100px"></td>      
                        <td align="center"><h2><?php echo $row4[6];?> <?php echo $row4[7];?> </h2><input type="hidden" name="ongkan_num" value="<?php echo $row4[0];?>" readonly></td>
                        <td align="center"><h2><?php echo $row4[8];?></h2><input type="hidden" name="std_year"value="<?php echo $row4[7];?>" readonly></td>
                        <td align="center"><h2><?php echo $row4[3];?></h2><input type="hidden" name="sapa_fac"value="<?php echo $row4[3];?>" readonly></td>
                        
                        </form>
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table><br><hr>
                
                <h1>สโมสรนักศึกษา <?php echo "$year1"; ?></h1><br>
                <table class="table">
                    <thead class="thead-dark">
                    <tr align="center">
                        <th scope="col">คณะ</th>                                          
                        <th scope="col">วัน</th>
                        <th scope="col">เลลา</th>
                        <th scope="col">รายชื่อพรรค</th>
                    </tr>
                    </thead>
                    <?php
                        while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr align="center">
                        <form method="GET" action="frm_ongkan_candidate.php">                  
                        <td><h4>คณะ<?php echo $row2[6];?></h4><input type="hidden" name="samo_fac" value="<?php echo $row2[6];?>" readonly></td>
                        <td><h4><?php list($y,$m,$d)=explode('-',$row2[2]); echo$d.'/'.$m.'/'.$y; ?></h4></td>
                        <td><h4><?php echo $row2[3];?> - <?php echo $row2[4];?></h4></td>
                        <td><button class="btn btn-dark" type="submit"  onClick="this.form.action='show_electionsamo_user.php'; submit()"><h3>รายชื่อพรรค</h3></button></td>
                        
                        </form>
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table><hr>
                        
                </div>
                <?php
                        include 'rs.php';
                    ?>
                <?php
                            include 'right.php';                          
                ?>                
                </div>
                                      
            </div><!-- end grid -->                            
    </body>
    <?php
    include 'footer.php';                          
    ?> 
</html>
