<?php

$number = 1;
while($number < 5){
    if(isset($_GET['num'.$number])) {
       if($number == 1){
        echo "นายนุตดี ยาหมาย ถูกเลือก";     
        echo '<br>';
        }
        if($number == 2){
        echo "นายอาซาน สาล่าห์ ถูกเลือก";
        echo '<br>';
        }
        if($number == 3){
        echo "นายประวิทย์ หมัดหมาน ถูกเลือก";
        }
    }
    $number++;
}



?>