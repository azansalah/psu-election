<?php
        include 'session.php';
        session_start();
        require 'connectdb.php';
        
        
        
        $query1 = "SELECT * FROM electionset";
        $result1 = mysqli_query($dbcon, $query1);      
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);

        $query2 = "SELECT * FROM electionset_samo INNER JOIN election_type ON electionset_samo.electionset_name = election_type.election_id WHERE electionset_name = '003'AND electionset_year = '2561' ";
        $result2 = mysqli_query($dbcon, $query2);
        
        
        $year1 = $row3['electionset_year'];
        
        $year = $row['electionset_year'];
        $electionday = $row['electionset_date']; 
        $starttime = $row['electionset_starttime'];
        $endtime = $row['electionset_endtime'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;
                border: 0;
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                    include 'header.php';
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <br><br>
            
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">   
                <h1>การเลือกสโมสรนักศึกษา <?php echo "$year1"; ?></h1>
                &emsp;&emsp;<font size="5"color="red" >ขันตอนการเลือกตั้ง</font><br>
                &emsp;&emsp;<font size="4" > 1. กดเลือกคณะ <?php echo "$s_faculty"; ?> </font><br>
                &emsp;&emsp;<font size="4"> 2. เลือกพรรคที่ต้องการลงคะแนน </font><br>
                &emsp;&emsp;<font size="4"> 3. กดลงคะแนน และกดตกลง </font><br><br>
                <table class="uk-width-7-10 uk-text-bold">
                    <thead>
                    <tr>                                
                    <th></th>
                    </tr>
                    </thead>
                    <?php
                        while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                    ?>
                    <tbody>
                    <tr>
                        <form method="GET" action="">                  
                        <td align="center"><input type="hidden" name="samo_fac" value="<?php echo $row2[6];?>" readonly></td>
                        <td align="center"><button class="btn btn-dark" type="submit" value="รายชื่อพรรค" style="width:700px; " value="20" onClick="this.form.action='election_samo_fac.php'; submit()"><h2>คณะ<?php echo $row2[6];?></h2></button></td>
                        </form>
                    </tr>
                    </tbody>         
                    <?php 
                    }
                        mysqli_free_result($result);
                        mysqli_close($dbcon);
                    ?>
                </table>      
                </div>
                <?php
                        include 'rs.php';
                ?>
                <?php
                            include 'right.php';                          
                ?>
                
                </div>
                                      
            </div><!-- end grid --> 
            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
