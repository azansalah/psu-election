<?php
        require 'connectdb.php';
        
        $year = $_GET['elect_year'];
        
        $query = "SELECT * FROM ongkan_team WHERE election_year = '$year'";
        $result1 = mysqli_query($dbcon, $query);
        
        
        $query2 = "SELECT COUNT(election_year) FROM ongkan_team WHERE election_year = '$year' ";
        $result2 = mysqli_query($dbcon, $query2);
        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);                
        $result1_ongkan = $row2['COUNT(election_year)'];    
        
        $query4 = "SELECT COUNT(vote_no) FROM resault_ongkan WHERE election_year = '$year'";
        $result4 = mysqli_query($dbcon, $query4);
        $row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC);
        $all = $row4['COUNT(vote_no)'];    
        
        $query5 = "SELECT COUNT(vote_no) FROM resault_ongkan WHERE election_year = '$year' AND vote_no = '0'";
        $result5 = mysqli_query($dbcon, $query5);
        $row5 = mysqli_fetch_array($result5, MYSQLI_ASSOC);
        $vote = $row5['COUNT(vote_no)'];         
        
        $query6 = "SELECT COUNT(vote_no) FROM resault_ongkan WHERE election_year = '$year' AND vote_no = '1'";
        $result6 = mysqli_query($dbcon, $query6);
        $row6 = mysqli_fetch_array($result6, MYSQLI_ASSOC);
        $vote_no = $row6['COUNT(vote_no)'];
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <center>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <br>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
        <br><h1>ผลคะแนนการเลือกตั้งองค์การบริหาร องค์การนักศึกษา <?php echo "$year"; ?> </h1><br><br>
        <table class="table">
            <thead class="thead-dark" >
            <tr align="center">
                <th scope="col">โลโก้พรรค</th>
                <th scope="col">หมายเลขพรรค</th>
                <th scope="col">ชื่อพรรค</th>
                <th scope="col">ผลคะแนน</th>
            </tr>
        <?php
                $min = 0;
                $max = 0;
                while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)) {
        ?>
        <tr align="center">
            <td><img src="image_ongkan/logo/<?php echo $row1[4];?>" width="100px" height="100px"></td>
            <form method="GET" action="frm_ongkan_candidate.php">
            <td><h2><?php echo $row1[0];?></h2><input align="right" type="hidden" name="ongkan_num" value="<?php echo $row1[0];?>" readonly></td>
            <td><h2><?php echo $row1[1];?></h2><input type="hidden" name="ongkan_name" value="<?php echo $row1[1];?>" readonly></td>
            <td><font color="red" > <h2><?php 
            $query3 = "SELECT COUNT(ongkan_num) FROM resault_ongkan WHERE election_year = '$year' AND ongkan_num = '$row1[0]'";
            $result3 = mysqli_query($dbcon, $query3);
            $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);                
            $result3_ongkan = $row3['COUNT(ongkan_num)'];
            
            /*if($result3_ongkan > $max)
                $max = $result3_ongkan;
            if($result3_ongkan < $min)
                $min = $result3_ongkan;*/
                
            echo $result3_ongkan;       
            ?></h2></font></td>
            </form>
        </tr>
        <?php 
                }
                mysqli_free_result($result1);
         ?>
        </table>
        
        <br><h1>สรุปสถิติการเข้าร่วมการเลือกตั้ง</h1><br>
         <table class="table">
            <thead class="thead-dark" >
            <tr align="center">
                <th scope="col">จำนวนผู้มาใช้สิทธิ์ทั้งหมด</th>
                <th scope="col">ลงคะแนน</th>
                <th scope="col">ไม่ประสงค์ลงคะแนน</th>
            </tr>
            
        <tr align="center">
            <td><h2><?php echo $all;?></h2></td>
            <td><h2><?php echo $vote;?></h2></td>
            <td><h2><?php echo $vote_no;?></h2></td>
            </form>
        </tr>
        </table>
        
        </center>     
                        
                </div>                               
                </div>                      
            </div><!-- end grid -->                            
    </body>
    <?php
    include 'footer.php';                          
    ?>
</html>