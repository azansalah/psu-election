<?php
        include 'session.php';
        session_start();
        require 'connectdb.php';
        
        $query1 = "SELECT * FROM tblogin";
        $result1 = mysqli_query($dbcon, $query1);
        $row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        
        
        
        
        $query2 = "SELECT * FROM resault_ongkan";
        $result2 = mysqli_query($dbcon, $query2);       
        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);
        
        $date = $row2['date'];
        
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
    </head>
    <body>
        <?php
                    include 'header.php';
        ?>
        <br><br>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
                   <?php
                        if ($_GET['code'] == 1) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>คุณได้ลงคะแนนเสียงไปแล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_ongkan.php">';
                        }else if ($_GET['code'] == 2) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_ongkan.php">';
                        }else if ($_GET['code'] == 3) {
                            echo '<div class="uk-alert uk-alert-sucsess"> <h2>ลงคะแนนเสียงเรียบร้อยแล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_ongkan.php">';
                        }else if ($_GET['code'] == 32) {
                            echo '<div class="uk-alert uk-alert-sucsess"> <h2>ลงคะแนนเสียงเรียบร้อยแล้ว(ไม่ประสงลงคะแนน)</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_ongkan.php">';
                           //องค์การ 
                            
                        }else if ($_GET['code'] == 4) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>คุณได้ลงคะแนนเสียงไปแล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_samo.php">';
                        }else if ($_GET['code'] == 5) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_samo_fac.php?samo_fac=วิศวกรรมศาสตร์">';
                        }else if ($_GET['code'] == 6) {
                            echo '<div class="uk-alert uk-alert-sucsess"> <h2>ลงคะแนนเสียงเรียบร้อยแล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_samo.php">';    
                        }else if ($_GET['code'] == 7) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>กรุณาเลือกคณะของคุณให้ถูกต้อง</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_samo.php">'; 
                        }else if ($_GET['code'] == 62) {
                            echo '<div class="uk-alert uk-alert-sucsess"> <h2>ลงคะแนนเสียงเรียบร้อยแล้ว(ไม่ประสงค์ลงคะแนน)</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_samo.php">';    
                        
                           //สโม
                            
                        }else if ($_GET['code'] == 8) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ขออภัยท่านได้เลือกเบอร์นี้แล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_sapa.php?vote=1">';
                        }else if ($_GET['code'] == 9) {
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_sapa.php">';
                        }else if ($_GET['code'] == 10) {
                            echo '<div class="uk-alert uk-alert-sucsess"> <h2>ลงคะแนนเสียงเรียบร้อยแล้ว</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_sapa.php?vote=1">';    
                        }else if ($_GET['code'] == 11) {
                            echo '<div class="uk-alert uk-alert-sucsess"> <h2>ลงคะแนนเสียงเรียบร้อยแล้ว(ไม่ประสงค์ลงคะแนน)</h2> </div>';
                            echo '<input type="button" value="ตกลง" class="uk-button" onclick=window.location.href="election_sapa.php">';
                        }    
                           //สภา
                    ?>    
                </div>
                <?php
                        include 'right.php';                     
                        
                        
                ?>
                    
            </div><!-- end grid -->                  
        </div>          
    </body>
</html>
