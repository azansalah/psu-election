<?php
        include 'session';
        require 'connectdb.php';
?>
<html>
    
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

        
        <title>เพิ่มรายละเอียด</title>
    </head>
    <body>
        <?php
            include 'header_admin.php';                  
        ?>
    <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
        <div class="uk-grid" data-uk-grid-margin> 
            <div class="uk-width-medium-5-4" style="font-coler: " >
            
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
             
            
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
                    
                    <form class="uk-form" action="add_info.php" method="post">
                    <fieldset data-uk-margin>
                        
                       <legend>เข้าสู่ระบบครั้งแรก กรุณากรอกข้อมูลส่วนตัว</legend>
                       <input type="text" placeholder="ชื่อ" name="name" required><br><br>
                       <input type="text" placeholder="นามสกุล" name="last_name" required><br><br>
                       <input type="text" placeholder="รหัสนักศึกษา" name="std_id" required><br><br>
                       <input type="email" placeholder="Email" name="email" required><br><br>
                       
                       <?php
                            $q = "SELECT * FROM faculty_type";
                            $result = mysqli_query($dbcon, $q);
                        ?>
                        <select name="faculty" id="ongkan_fac">
                            <option value="">----------คณะ----------</option>
                                 <?php
                                    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                    echo "<option value='$row[1]'>$row[1]</option>";
                                    }
                                ?>
                        </select><br><br>
                       
                        <select type ="text" name="year" >
                            <option value="">..............ชั้นปี..............</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select><br><br><br><br>
                       <input type="submit" value="บันทึกข้อมูล" class="uk-button" > 
                    </fieldset>
                    </form>
                    
                </div>
                
                <?php
                        include 'right.php';
                ?>
                
            </div><!-- end grid -->                  
        </div>
        
        <?php
                 include 'rs.php';
        ?>
        
 
            </div>                               
        </div>                      
    </div><!-- end grid -->                            
    <?php
        include 'footer.php';                          
    ?>
</html>
