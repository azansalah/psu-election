<?php
        require 'connectdb.php';
        
        $faculty_search = $_GET['ongkan_faculty'];
        $teamname_search = $_GET['team_name'];
        
        if($faculty_search == "" AND $teamname_search == ""){
            $query = "SELECT * FROM ongkan_candidate INNER JOIN position_type ON ongkan_candidate.std_pos = position_type.position_id ORDER BY ongkan_name,ongkan_num,std_pos";
        }else if($faculty_search == "" AND $teamname_search != ""){
            $query = "SELECT * FROM ongkan_candidate INNER JOIN position_type ON ongkan_candidate.std_pos = position_type.position_id WHERE ongkan_name = '$teamname_search' ORDER BY ongkan_name,ongkan_num,std_pos";
        }else if($faculty_search != "" AND $teamname_search == ""){
            $query = "SELECT * FROM ongkan_candidate INNER JOIN position_type ON ongkan_candidate.std_pos = position_type.position_id WHERE ongkan_fac = '$faculty_search' ORDER BY ongkan_name,ongkan_num,std_pos";
        }
        else{
            $query = "SELECT * FROM ongkan_candidate INNER JOIN position_type ON ongkan_candidate.std_pos = position_type.position_id WHERE ongkan_fac = '$faculty_search' AND ongkan_name = '$teamname_search' ORDER BY ongkan_name,ongkan_num,std_pos";            
        }
        $result = mysqli_query($dbcon, $query);

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>แสดงข้อมูลนักศึกษา</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <h2>ข้อมูลผู้สมัคเลือกตั้งองค์การบริหาร องค์การนักศึกษา ทั้งหมด</h2>
        
        <form method="GET" action="show_electionongkan.php">
            
        
        <label>ชื่อพรรค: </label>
            <input type="text" name="team_name">
        <input type="submit" value="แสดง"><br><br>
            
        </form>
        <table>
            <tr>
                <th>ลำดับ</th>
                <th>เบอร์</th>
                <th>ชื่อพรรค</th>
                <th>ชื่อ-นามสกุล</th>
                <th>รหัสนักศึกษา</th>
                <th>คณะ</th>
                <th>ชั้นปี</th>
                <th>ตำแหน่ง</th>            
            </tr>
            <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            ?>
            <tr>
                <td><?php echo $row['std_pos'];?></td>
                <td><?php echo $row['ongkan_num'];?></td>
                <td><?php echo $row['ongkan_name'];?></td> 
                <td><?php echo $row['std_name'];?></td>
                <td><?php echo $row['std_id'];?></td>
                <td><?php echo $row['ongkan_fac'];?></td>
                <td><?php echo $row['std_year'];?></td>
                <td><?php echo $row['position_name'];?></td>
            </tr>
        <?php 
                }
                mysqli_free_result($result);
                mysqli_close($dbcon);
         ?>
    </table>
        <br>
        <a href='home_ongkan.php'>หน้าแรก</a>
    </body>
</html>




