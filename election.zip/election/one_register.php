<?php

        require 'connectdb.php';
        
        $studentv_name = $_POST['studentv_name'];
        $studentv_lastname = $_POST['studentv_lastname'];
        $studentv_id = $_POST['studentv_id'];
        $studentv_faculty = $_POST['studentv_faculty'];
        $studentv_year = $_POST['studentv_year'];
        
        
        
        $party_name = $_POST['party_name'];
        $party_number = $_POST['party_number'];
        $t_name = $_POST['t_name'];
        $t_lastname = $_POST['t_lastname'];
        $t_id = $_POST['t_id'];
        $t_faculty = $_POST['t_faculty'];
        $t_year = $_POST['t_year'];
        
        
        $one_number = $_POST['one_number'];
        $one_name = $_POST['one_name'];
        $one_lastname = $_POST['one_lastname'];
        $one_id = $_POST['one_id'];
        $one_faculty = $_POST['one_faculty'];
        $one_year = $_POST['one_year'];
        
        
        //$query = "INSERT INTO voterdb (studentv_name, studentv_lastname, studentv_id, studentv_faculty,studentv_year ) VALUES ('$studentv_name', '$studentv_lastname', '$studentv_id', '$studentv_faculty', '$studentv_year')";
        //$query = "INSERT INTO teamdb (party_name, party_number, t_name, t_lastname, t_id,t_faculty, t_year ) VALUES ('$party_name', '$party_number', '$t_name', '$t_lastname', '$t_id', '$t_faculty', '$t_year')";
        $query = "INSERT INTO onedb (one_number, one_name, one_lastname, one_id, one_faculty, one_year ) VALUES ('$one_number', '$one_name', '$one_lastname', '$one_id', '$one_faculty', '$one_year')";
        
        $result = mysqli_query($dbcon, $query);
        
        if ($result) {
            echo "เพิ่มข้อมูลเรียบร้อยแล้ว" ;
            echo "<hr>";
            echo "<a href='show_one.php'>แสดงข้อมูล</a>";
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);
