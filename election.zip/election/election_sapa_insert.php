<?php
        include 'session.php';
        require 'connectdb.php';
        
        $now_year = (date("Y")+543);
        $voteno = $_GET['voteno'];
                
        $sapa_num = $_GET['sapa_num'];
        $std_id = $s_std_id;
        $sapa_name = $_GET['sapa_name'];
        $sapa_lastname = $_GET['sapa_lastname'];
        $std_year = $_GET['std_year'];
        $sapa_fac = $_GET['sapa_fac'];
        $sapa_type = $_GET['type'];
        $accept = $_GET['accept'];
                
        $query1 = "SELECT * FROM electionset_sapa WHERE electionset_year = $now_year ";
        $result1 = mysqli_query($dbcon, $query1);
        $row = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        $election_year = $row['electionset_year'];
        
        $query2 = "SELECT * FROM resault_sapa WHERE std_id = '$s_std_id' AND sapa_type = 'normal' ";
        $result2 = mysqli_query($dbcon, $query2);       
   
        $electionday = $row['electionset_date']; 
        $starttime = $row['electionset_starttime'];
        $endtime = $row['electionset_endtime'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
        
        while ($row = mysqli_fetch_array($result2, MYSQLI_ASSOC)){
            if($row['sapa_num'] == $sapa_num){
                $check = 1;
            }else{
                $check = 0;
            }
        }
        
        if($voteno == 1){
            $query3 = "INSERT INTO resault_sapa (std_id, name, lastname, faculty, sapa_num, sapa_name, sapa_lastname, sapa_fac, date, time, election_year, sapa_type, accept, vote_no) VALUES ('$std_id','$s_name', '$s_lastname', '$s_faculty', '0', '0', '0', '0', '$today', '$todaytime', '$now_year', '0', '0', '$voteno') ";
            $result3 = mysqli_query($dbcon, $query3);
                
                if($result3){
                    header("Location: election_warning.php?code=11");
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }
                 
        } 
           
        else if($result2->sapa_num >= 3){
            header("Location: election_warning.php?code=8");
        }
        else if(!($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime)) {
            header("Location: election_warning.php?code=2");
        }
        else if($check == 1){
            header("Location: election_warning.php?code=8");
        }else{
            $query = "INSERT INTO resault_sapa (std_id, name, lastname, faculty, sapa_num, sapa_name, sapa_lastname, sapa_fac, date, time, election_year, sapa_type, accept) VALUES ('$std_id','$s_name', '$s_lastname', '$s_faculty', '$sapa_num', '$sapa_name', '$sapa_lastname', '$sapa_fac', '$today', '$todaytime', '$election_year', '$sapa_type', '$accept') ";
            $result = mysqli_query($dbcon, $query);
                
                if($result){
                    header("Location: election_warning.php?code=10?$result2->num_rows");
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }
                 
        } 
                
    mysqli_close($dbcon);    
                    
