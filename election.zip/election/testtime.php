<?php
include 'session.php';
require 'connectdb.php';
$sapa_num = $_GET['sapa_num'];

$query = "SELECT * FROM electionset";
$result1 = mysqli_query($dbcon, $query);      
$row = mysqli_fetch_array($result1, MYSQLI_ASSOC);

$query2 = "SELECT * FROM resault_ongkan";
$result2 = mysqli_query($dbcon, $query2);       
$row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);

$std_id = $row2['std_id'];

$electionday = $row['electionset_date']; 
$starttime = $row['electionset_starttime'];
$endtime = $row['electionset_endtime'];

$today = date("Y-m-d");
$todaytime = date("H:i:s");

$date= "$electionday";
list($y,$m,$d)=explode('-',$date);
echo$d.'/'.$m.'/'.$y;

echo "<br>";

echo "election on $electionday at $starttime น. $endtime น.";
echo "<br>";
echo "you come to election on $today at $todaytime น.";


echo "<br>";




if($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime){
    echo "อยู่ในช่วงเวลาเลือกตั้ง";
} else {
    echo "ไม่อยู่ในช่วงเวลาเลือกตั้ง";
}
echo "<br>";

if($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime){
    echo "อยู่ในช่วงเวลาเลือกตั้ง";
}

function TimeDiff($strTime1,$strTime2)
{
return (strtotime($strTime2) - strtotime($strTime1))/  ( 60 * 60 ); // 1 Hour =  60*60
}
?>

<!DOCTYPE html>
<html>
    <body>
        <hr>
        <?php echo $difdate, $diftime1, $diftime2; ?>
        <button onclick="myFunction()">Click me</button>
            <script>
                function myFunction() {
                    if ( 1 == 1) {
                        alert('Some message1');
                    }
                    else {
                        alert('ไม่อยู่ในช่วงเวลา');
                    }
                }
            </script>
    </body>
</html>
