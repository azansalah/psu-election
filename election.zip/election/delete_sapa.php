<?php
        require 'connectdb.php';
        
        $electionset_id = $_GET['electionset_id'];
        $sapa_num = $_GET['sapa_num'];
        $sapa_name = $_GET['sapa_name'];
        
        $q = "DELETE FROM electionset_sapa WHERE electionset_id='$electionset_id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: create_election_sapa_show.php");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);