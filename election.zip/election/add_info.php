<?php
                include 'session.php';
                require 'connectdb.php';
                
                $name = $_POST['name'];
                $last_name = $_POST['last_name'];
                $email = $_POST['email'];
                $faculty = $_POST['faculty'];
                $year = $_POST['year'];
                $std_id = $_POST['std_id'];
                
                $query1 = "UPDATE tblogin SET details_status = 'yes' WHERE login_id = '$s_login_id'";
                $result1 = mysqli_query($dbcon, $query1);
                
                $query2 = "UPDATE tblogin SET name = '$name', last_name = '$last_name', login_email = '$email', faculty = '$faculty', year = '$year', std_id = '$std_id'  WHERE login_id = '$s_login_id'";
                $result2 = mysqli_query($dbcon, $query2);
                
                if($result1 AND $result2){
                    header("Location: add_info_success.php?code=1");
                } else {
                    echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon);
                }
                
                mysqli_close($dbcon);                  