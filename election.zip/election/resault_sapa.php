<?php
        require 'connectdb.php';
        
        
        $id = $_GET['id'];
        $std_name = $_GET['std_name'];
        $year = $_GET['elect_year'];
        $type = 'normal';
        
      
        $query = "SELECT * FROM sapa_candidate  WHERE year = '$year' AND type = 'normal' ORDER BY std_num ";        
        $result = mysqli_query($dbcon, $query);
        
        $query2 = "SELECT * FROM sapa_candidate  WHERE year = '$year' AND type = 'fac' ORDER BY std_num ";
        $result2 = mysqli_query($dbcon, $query2);
        
        $query7 = "SELECT std_id, COUNT(vote_no) FROM resault_sapa WHERE election_year = '$year'";
        $result7 = mysqli_query($dbcon, $query7);
        $row7 = mysqli_fetch_array($result7, MYSQLI_ASSOC);
        $all = $row7['COUNT(vote_no)'];        
        
        $query8 = "SELECT COUNT(vote_no) FROM resault_sapa WHERE election_year = '$year' AND vote_no = '0'";
        $result8 = mysqli_query($dbcon, $query8);
        $row8 = mysqli_fetch_array($result8, MYSQLI_ASSOC);
        $vote = $row8['COUNT(vote_no)'];              
        
        $query9 = "SELECT COUNT(vote_no) FROM resault_sapa WHERE election_year = '$year' AND vote_no = '1'";
        $result9 = mysqli_query($dbcon, $query9);
        $row9 = mysqli_fetch_array($result9, MYSQLI_ASSOC);
        $vote_no = $row9['COUNT(vote_no)'];
        
        $query10 = "SELECT * FROM electionset_sapa WHERE electionset_year = '$year'";
        $result10 = mysqli_query($dbcon, $query10);
        $row10 = mysqli_fetch_array($result10, MYSQLI_ASSOC);
        $win_score_normal = $row10['win_score_normal'];
        $win_score_fac = $row10['win_score_fac'];

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
        <body>
            <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
            <br><h1>ข้อมูลผู้สมัคเลือกตั้งสภานักศึกษา แบบทั่วไป ปีการศึกษา <?php echo "$year"; ?></h1><br><br>       
        <h1> แบบทั่วไป </h1><br>
                </center>
        <font color ="red" ><h3> เกณฑ์การตัดสินผู้ลงสมัครต้องมีคะแนนโหวตมากกว่า <?php echo $win_score_normal; ?> คะแนน </h3></font>
        <table class="table">
            <thead class="thead-dark" >
                <tr align="center">
                    <th scope="col">เบอร์</th>
                    <th scope="col">รูป</th>                                   
                    <th scope="col">ชื่อ</th>
                    <th scope="col">นามสกุล</th>
                    <th scope="col">รหัสนักศึกษา</th>
                    <th scope="col">คณะ</th>
                    <th scope="col">ชั้นปี</th>             
                    <th scope="col"><font color="red" >คะแนน</font></th>
                    <th scope="col"><font color="red" >ผล</font></th>
                    
                    
                </tr>
                <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                ?>
                <tr align="center">
                    <td><h5><?php echo $row[4];?></h5></td>
                    <td><img src="image_sapa/<?php echo $row[9];?>" width="100px" height="100px"></td>                   
                    <td><h5><?php echo $row[6];?></h5></td>
                    <td><h5><?php echo $row[7];?></h5></td>
                    <td><h5><?php echo $row[5];?></h5></td>
                    <td><h5><?php echo $row[3];?></h5></td>
                    <td><h5><?php echo $row[8];?></h5></td>
                    
                    <td><font color="red" > <h5><?php 
                        $query3 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'normal' AND sapa_num = '$row[4]'";
                        $result3 = mysqli_query($dbcon, $query3);
                        $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);                
                        $result3_sapa = $row3['COUNT(sapa_num)'];
                            echo $result3_sapa;       
                        ?></h5></font>
                    </td>
                    <td><font color="red" > <h5><?php 
                        $query3 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'normal' AND sapa_num = '$row[4]'";
                        $result3 = mysqli_query($dbcon, $query3);
                        $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);                
                        $result3_sapa = $row3['COUNT(sapa_num)'];
                            if($result3_sapa > $win_score_normal){
                                echo '<font color="green" >ผ่าน</font>';
                            }else{
                                echo 'ไม่ผ่าน';
                            }
                        ?></h5></font>
                    </td>
                </tr>
                <?php 
                    }
                    mysqli_free_result($result);
                ?>               
        </table><br>
        
        <br><h3>สรุปสถิติการเข้าร่วมการเลือกตั้ง (แบบทั่วไป)</h3>
         <table class="table">
            <thead class="thead-dark" >
            <tr align="center">
                <th scope="col">จำนวนผู้มาใช้สิทธิ์ทั้งหมด</th>
                <th scope="col">ลงคะแนน</th>
                <th scope="col">ไม่ประสงค์ลงคะแนน</th>
            </tr>
            
        <tr align="center">
            <td><h2><?php echo $all;?></h2></td>
            <td><h2><?php echo $vote;?></h2></td>
            <td><h2><?php echo $vote_no;?></h2></td>
            </form>
        </tr>
        </table><br><br><hr><br>
        
        <center><h1> แบบสัดส่วนคณะ </h1></center><br>
        <font color ="red" ><h3> เกณฑ์การตัดสินผู้ลงสมัครต้องมีผลการรับรองสิทธ์มากกว่า <?php echo $win_score_fac; ?> เปอร์เซ็นจากผู้ลงคะแนนทั้งหมด </h3></font>
        <table class="table">
            <thead class="thead-dark" >
                <tr align="center">
                    <th scope="col">ลำดับ</th>
                    <th scope="col">รูป</th>                                   
                    <th scope="col">ชื่อ</th>
                    <th scope="col">นามสกุล</th>
                    <th scope="col">รหัสนักศึกษา</th>
                    <th scope="col">ชั้นปี</th>
                    <th scope="col">คณะ</th>                     
                    <th scope="col"><font color="green" >รับรองสิทธิ์</font></th>
                    <th scope="col"><font color="red" >ไม่รับรองสิทธิ์</font></th>
                    <th scope="col"><font color="blue" >ทั้งหมด</font></th>
                    <th scope="col"><font color="blue" >ร้อยละ (%)</font></th>
                    <th scope="col"><font color="blue" >ผล</font></th>
                    
                </tr>
                <?php
                    while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                ?>
                <tr align="center">
                    <td><h5><?php echo $row2[4];?></h5></td>
                    <td><img src="image_sapa/<?php echo $row2[9];?>" width="100px" height="100px"></td>                   
                    <td><h5><?php echo $row2[6];?></h5></td>
                    <td><h5><?php echo $row2[7];?></h5></td>
                    <td><h5><?php echo $row2[5];?></h5></td>
                    <td><h5><?php echo $row2[8];?></h5></td>
                    <td><h5><?php echo $row2[3];?></h5></td>
                    <td><font color="green" ><h5><?php 
                        $query4 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]' AND accept = '1' ";
                        $result4 = mysqli_query($dbcon, $query4);
                        $row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC);                
                        $result4_sapa = $row4['COUNT(sapa_num)'];
                            echo $result4_sapa;     
                        ?></h5></font></td>
                    <td><h5><font color="red" ><?php 
                        $query5 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]' AND accept = '0' ";
                        $result5 = mysqli_query($dbcon, $query5);
                        $row5 = mysqli_fetch_array($result5, MYSQLI_ASSOC);                
                        $result5_sapa = $row5['COUNT(sapa_num)'];
                            echo $result5_sapa;       
                        ?></h5></font></td>
                    <td><h5><font color="blue" ><?php 
                        $query6 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]'";
                        $result6 = mysqli_query($dbcon, $query6);
                        $row6 = mysqli_fetch_array($result6, MYSQLI_ASSOC);                
                        $result6_sapa = $row6['COUNT(sapa_num)'];
                            echo $result6_sapa;       
                        ?></h5></font></td>
                    <td><h5><font color="blue" ><?php
                        $query4 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]' AND accept = '1' ";
                        $result4 = mysqli_query($dbcon, $query4);
                        $row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC);                
                        $result4_sapa = $row4['COUNT(sapa_num)'];
                         
                    
                        $query6 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]'";
                        $result6 = mysqli_query($dbcon, $query6);
                        $row6 = mysqli_fetch_array($result6, MYSQLI_ASSOC);                
                        $result6_sapa = $row6['COUNT(sapa_num)'];
                        
                            
                        $result_persen = (($result4_sapa * 100)/$result6_sapa);
                        $result_persen = number_format($result_persen, 2, '.', '');

                            echo $result_persen;
                        ?></h5></font></td>
                    <td><h5><font color="blue" ><?php
                        $query4 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]' AND accept = '1' ";
                        $result4 = mysqli_query($dbcon, $query4);
                        $row4 = mysqli_fetch_array($result4, MYSQLI_ASSOC);                
                        $result4_sapa = $row4['COUNT(sapa_num)'];
                         
                    
                        $query6 = "SELECT COUNT(sapa_num) FROM resault_sapa WHERE election_year = '$year' AND sapa_type = 'fac' AND sapa_num = '$row2[4]'";
                        $result6 = mysqli_query($dbcon, $query6);
                        $row6 = mysqli_fetch_array($result6, MYSQLI_ASSOC);                
                        $result6_sapa = $row6['COUNT(sapa_num)'];
                        
                            
                        $result_persen = (($result4_sapa * 100)/$result6_sapa);
                            if($result_persen > $win_score_fac){
                                echo '<font size="4" color="green" >ผ่าน</font>';
                            }else{
                            echo '<font size="4" color="red" >ไม่ผ่าน</font>';
                            }
                        ?></h5></font></td>
                    </tr>
                    
                    
                <?php 
                    }
                    mysqli_free_result($result2);
                    mysqli_close($dbcon);
                ?>
        </table>
        
        
        
                </div>                               
            </div>                      
        </div><!-- end grid -->
        </center>
    </body><br><br>
    <?php
    include 'footer.php';                          
    ?>
</html>




