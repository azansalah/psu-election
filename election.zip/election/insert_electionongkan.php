<?php

        require 'connectdb.php';
        
        $ongkan_fac = $_POST['ongkan_fac'];
        $ongkan_name = $_POST['ongkan_name'];
        $ongkan_num = $_POST['ongkan_num'];
        $std_id = $_POST['std_id'];
        $std_name = $_POST['std_name'];
        $std_pos = $_POST['std_pos'];
        $std_year = $_POST['std_year'];
        
        //upload image
        $ext = pathinfo(basename($_FILES['std_image']['name']), PATHINFO_EXTENSION);
        $new_image_name = 'img_'.uniqid().".".$ext;
        $image_path = "image_ongkan/candidate/";
        $upload_path =$image_path.$new_image_name;
        //uploading
        $success = move_uploaded_file($_FILES['std_image']['tmp_name'], $upload_path);
        if($success==FALSE) {
            echo 'ไม่สามารถอัพโหลดรูปภาพได้';
            exit();
        }
        
        $std_image = $new_image_name;
        
        $query = "INSERT INTO ongkan_candidate (ongkan_fac, ongkan_name, ongkan_num, std_id, std_name, std_pos, std_year, std_image ) VALUES ('$ongkan_fac', '$ongkan_name', '$ongkan_num', '$std_id', '$std_name', '$std_pos', '$std_year', '$std_image')";
        
        $result = mysqli_query($dbcon, $query);
        
        if ($result) {
            header("Location: show_electionongkan.php?ongkan_num=$ongkan_num&ongkan_name=$ongkan_name");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);


