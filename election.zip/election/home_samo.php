<?php
        include 'secure/session.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> 
    </head>
        <body>
            <?php
                    include 'header_admin.php';                  
            ?>
            <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
                <div class="uk-grid" data-uk-grid-margin> 
                    <div class="uk-width-medium-5-4" style="font-coler: " ><br>
                        <center><br><br>
                        <h1>การเลือกตั้ง สโมสรนักศึกษา</h1><br><br>
                        <form method="post">
                            <button type="button" class="btn btn-outline-secondary" style="width:300px; font-size:20px" value="เพิ่มการเลือกตั้ง" onClick="this.form.action='create_election_samo.php'; submit()"><h3>เพิ่มการเลือกตั้ง</h3></button><br><br><br>
                            <button type="button" class="btn btn-outline-secondary" style="width:300px; font-size:20px" value="แสดงการเลือกตั้ง" onClick="this.form.action='create_election_samo_show.php'; submit()"><h3>แสดงการเลือกตั้ง</h3></button><br><br><br>
                            <button type="button" class="btn btn-outline-secondary" style="width:300px; font-size:20px" value="แสดงผลการเลือกตั้ง" onClick="this.form.action='resault_samo_select.php'; submit()"><h3>แสดงผลการเลือกตั้ง</h3></button><br><br><br>
                        </from>
                    </div>                               
                </div>                      
            </div>
        </body><br>
        <?php
            include 'footer.php';                          
        ?>
</html>




