<?php
        require 'connectdb.php';
        $elect_name = $_GET['elect_name'];
        $elect_fac = $_GET['elect_fac'];
        $elect_year = $_GET['elect_year'];
        $elect_date = $_GET['elect_date'];
        $elect_starttime = $_GET['elect_starttime'];
        $elect_endtime = $_GET['elect_endtime'];
        $faculty = $_GET['faculty'];
        
        $id = $_GET['electionset_id'];
        $id1 = $_GET['id1'];
        $q = "SELECT * FROM ongkan_team WHERE electionset_id='$id'";
        $res = mysqli_query($dbcon, $q);
        $row1 = mysqli_fetch_array($res, MYSQLI_ASSOC);
      

        
        
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
        <center>
            <body>
                <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
                <br><h1>เพิ่มพรรคการเลือกตั้ง สโมสรนักศึกษา</h1><br><br>
        </center>    
                    <form action="updated_ongkan_team.php" method="GET" enctype="multipart/form-data" name="form1" id="form1">
            <fieldset>
                <input type="hidden" name="id" value="<?php echo $id ?>">
                <input type="hidden" name="elect_name" value="<?php echo $elect_name ?>">
                <input type="hidden" name="elect_fac" value="<?php echo $elect_fac ?>">
                <input type="hidden" name="elect_year" value="<?php echo $elect_year ?>">
                <input type="hidden" name="elect_date" value="<?php echo $elect_date ?>">
                <input type="hidden" name="elect_starttime" value="<?php echo $elect_starttime ?>">
                <input type="hidden" name="elect_endtime" value="<?php echo $elect_endtime ?>">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">หมายเลขพรรค</span>
                    </div>
                    <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="team_number" value="<?php echo $row1['team_number'];?>">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">ชื่อพรรค</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="team_name" value="<?php echo $row1['team_name'];?>">
                </div>    
                <label>โลโก้พรรค: <input type="file" name="team_image"></label><br><br>
                <center><button name="submit" type="submit" name="submit" value="บันทึก" class="btn btn-secondary" style="width:200px; font-size:18px" >บันทึก</button></center>
            </fieldset>
        </form>
            </div>                               
                </div>                      
            </div><!-- end grid -->                            
    </body><br><br><br><br><br>
    <?php
    include 'footer.php';                          
    ?>        
    </body>
</html>





