<?php

        require 'connectdb.php';
        $electionset_id = $_GET['electionset_id'];
        $electionset_name = 2;
        $year = $_GET['year'];
        $date = $_GET['date'];
        $starttime = $_GET['starttime'];
        $endtime = $_GET['endtime'];
        $win_score_normal = $_GET['win_score_normal'];
        $win_score_fac = $_GET['win_score_fac'];
        
        $q = "UPDATE electionset_sapa SET electionset_date = '$date', electionset_starttime = '$starttime', electionset_endtime = '$endtime', electionset_year = '$year', win_score_normal = '$win_score_normal', win_score_fac = '$win_score_fac' WHERE electionset_id = '$electionset_id' ";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            header("Location: create_election_sapa_show.php");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);
