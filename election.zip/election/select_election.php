<center>
    <body>
        <meta charset="UTF-8">
        <title></title>
        <br>
        
        <h1>การเลือกตั้ง</h1>
            <br><br>
                <form method="post">  
                <button type="button" style="width:500px; font-size:20px" value="การเลือกตั้งองค์การบริหาร องค์การนักศึกษา" onClick="this.form.action='home_ongkan.php'; submit()"><h3>การเลือกตั้งองค์การบริหาร องค์การนักศึกษา</h3></button><br><br><br>
                <button type="button" style="width:500px; font-size:20px" value="การเลือกตั้งสภานักศึกษา" onClick="this.form.action='home_sapa.php'; submit()"><h3>การเลือกตั้งสภานักศึกษา</h3></button><br><br><br>
                <button type="button" style="width:500px; font-size:20px" value="การเลือกตั้งสโมสรนักศึกษา" onClick="this.form.action='home_samo.php'; submit()"><h3>การเลือกตั้งสโมสรนักศึกษา</h3></button>
                </form>
    </body>
</center>