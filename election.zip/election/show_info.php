<?php
        include 'session';
        require 'connectdb.php';
        session_start();
        $user = $_SESSION['login_username'];
        
        $query = "SELECT * FROM tblogin WHERE login_username ='$user'";
        $result1 = mysqli_query($dbcon, $query);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                include 'header.php';
        ?> 
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            
            <?php
                    
                    while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)) {
            ?>
            <br><br>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
                    <article class="uk-article">

                        <h1 class="uk-article-title">
                            <h1>ข้อมูลส่วนตัว</h1>
                        </h1><br>
                
                    <form class="uk-form" action="" method="post">
                        <fieldset data-uk-margin>
                            ชื่อ : <input type="text" name="name" value="<?php echo $row1[6];?>" readonly><br><br>
                            นามสกุล : <input type="text" name="last_name" value="<?php echo $row1[7];?>" readonly><br><br>
                            รหัสนักศึกษา : <input type="text" name="std_id" value="<?php echo $row1[10];?>" readonly><br><br>
                            Email : <input type="email" name="email" size="25" value="<?php echo $row1[3];?>" readonly><br><br>
                            คณะ : <input type="text" name="faculty" value="<?php echo $row1[8];?>" readonly><br><br>
                            ชั้นปี : <input type="text" name="year" value="<?php echo $row1[9];?>" readonly><br><br> 
                            
                            <a class="uk-button" href="edit_info.php">แก้ไขข้อมูล</a>
                        </fieldset>
                    </form>     
                    </article>
                </div>
                <?php 
                    }
                        mysqli_free_result($result1);
                        mysqli_close($dbcon);
                            include 'right.php';
                ?>                
                </div>
                    <?php
                        include 'rs.php';
                    ?>                            
            </div><!-- end grid -->                            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
