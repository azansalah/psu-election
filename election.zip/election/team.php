<?php
        include 'secure/session.php';
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <h1>ยินดีต้อนรับ</h1>
        <p>คุณ <?php echo $s_login_username; ?> อีเมล: <?php echo $s_login_email; ?></p>
        
        
        <p>
            <a href="team_add.php">เพิ่มพรรคการเลือกตั้ง</a>
            <br>
            <a href="create_election_show.php">แสดงพรรคการเลือกตั้ง</a>
        </p>
        
        <hr>
    </body>
</html>
