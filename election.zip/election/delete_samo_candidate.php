<?php
        require 'connectdb.php';
        
        $id = $_GET['id'];
        $samo_num = $_GET['samo_num'];
        $samo_name = $_GET['samo_name'];
        
        $q = "DELETE FROM samo_candidate WHERE id='$id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_electionsamo.php?samo_num=$samo_num&samo_name=$samo_name");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);
        
        

