<?php

        require 'connectdb.php';
        
        $electionset_name = 3;
        $year = $_POST['year'];
        $date = $_POST['date'];
        $starttime = $_POST['starttime'];
        $endtime = $_POST['endtime'];
        $samo_fac = $_POST['samo_fac'];
        
        $q = "INSERT INTO electionset_samo (electionset_name, electionset_date, electionset_starttime, electionset_endtime, electionset_year, electionset_faculty) VALUES ('$electionset_name', '$date', '$starttime', '$endtime', '$year', '$samo_fac')";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            echo "เพิ่มข้อมูลเรียบร้อยแล้ว" ;
            echo "<hr>";
           
            echo "<a href='home_samo.php'>กลับหน้าหลัก</a>";
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);

