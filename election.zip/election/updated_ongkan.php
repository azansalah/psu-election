<?php

        require 'connectdb.php';
        $electionset_id = $_GET['electionset_id'];
        $electionset_name = 1;
        $year = $_GET['year'];
        $date = $_GET['date'];
        $starttime = $_GET['starttime'];
        $endtime = $_GET['endtime'];
        
        $q = "UPDATE electionset SET electionset_date = '$date', electionset_starttime = '$starttime', electionset_endtime = '$endtime', electionset_year = '$year' WHERE electionset_id = '$electionset_id' ";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            header("Location: create_election_ongkan_show.php");
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);
