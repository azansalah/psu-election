<?php
        include 'session';
        require 'connectdb.php';
        session_start();
        
        $samo_num = $_GET['samo_num'];
        $samo_name = $_GET['samo_name'];
        
      
        $query = "SELECT * FROM samo_candidate INNER JOIN position_type_samo ON samo_candidate.std_pos = position_type_samo.position_id WHERE samo_num = '$samo_num' AND samo_name = '$samo_name' ORDER BY samo_name,samo_num,std_pos";            
        
        $result = mysqli_query($dbcon, $query);
        $row1 = mysqli_fetch_array($result, MYSQLI_ASSOC)
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
         <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
            <br><br>
            <h1>ข้อมูลผู้สมัคสโมสรนักศึกษา คณะ<?php echo $row1['samo_fac'];?> </h1>
            <h2>เบอร์ <?php echo "$samo_num"; ?> พรรค <?php echo "$samo_name"; ?></h2><br>
            <table class="table">
                <thead class="thead-dark">
                <tr align="center" >
                    <th scope="col">ลำดับ</th>
                    <th scope="col">รูป</th>
                    <th scope="col">เบอร์</th>
                    <th scope="col">ชื่อพรรค</th>
                    <th scope="col">ชื่อ-นามสกุล</th>
                    <th scope="col">รหัสนักศึกษา</th>
                    <th scope="col">คณะ</th>
                    <th scope="col">ชั้นปี</th>
                    <th scope="col">ตำแหน่ง</th>            
                </tr>
                </thead>
                <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                ?>
                <tbody>
                <tr>
                    <td align="center"><h3><?php echo $row['std_pos'];?></h3></td>
                    <td align="center"><img src="image_samo/candidate/<?php echo $row['std_image'];?>" width="100px" height="100px"></td>
                    <td align="center"><h3><?php echo $row['samo_num'];?></h3></td>
                    <td align="center"><h3><?php echo $row['samo_name'];?></h3></td> 
                    <td align="center"><h3><?php echo $row['std_name'];?></h3></td>
                    <td align="center"><h3><?php echo $row['std_id'];?></h3></td>
                    <td align="center"><h3><?php echo $row['samo_fac'];?></h3></td>
                    <td align="center"><h3><?php echo $row['std_year'];?></h3></td>
                    <td align="center"><h3><?php echo $row['position_name'];?></h3></td>
                </tr>
                </tbody>
                <?php 
                    }
                    mysqli_free_result($result);
                    mysqli_close($dbcon);
                ?>
            </table>
                                     
                </div><!-- end grid -->                  
            </div>
        </div>>
            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
