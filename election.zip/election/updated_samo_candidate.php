<?php
        require 'connectdb.php';
        $id = $_GET['id'];
        $samo_num = $_GET['samo_num'];
        $samo_name = $_GET['samo_name'];
        $std_name = $_GET['std_name'];
        $std_id = $_GET['std_id'];
        $samo_fac = $_GET['samo_fac'];
        $std_year = $_GET['std_year'];
        $std_pos = $_GET['std_pos'];
        
     $q = "UPDATE samo_candidate SET samo_num = '$samo_num', samo_name = '$samo_name', std_name = '$std_name', std_id = '$std_id', samo_fac = '$samo_fac', std_year = '$std_year', std_pos = '$std_pos' WHERE id = '$id' ";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
         header("Location: show_electionsamo.php?samo_num=$samo_num&samo_name=$samo_name");
     } else {
         echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon); 
     }
     
     mysqli_close($dbcon);
 