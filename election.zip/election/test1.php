<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form name="form1" action="test2.php" onsubmit="return validateForm1()">
            <input type="checkbox" name="num1" value="1">นายนุตดี ยาหมาย
               <br>
            <input type="checkbox" name="num2" value="1">นายอาซาน สาล่าห์
                <br>
            <input type="checkbox" name="num3" value="1">นายประวิทย์ หมัดหมาน
                <br>
            <input type="checkbox" name="num4" value="1">นายฟาริส มะหะหมัด
                <br><br>
            <input type="submit">
        </form> 
        <script>
function validateForm1(){
     var i=0;
     var max = 3;
     if(form1.num1.checked){ i++ }
     if(form1.num2.checked ){ i++ }
     if(form1.num3.checked ){ i++ }
     if(form1.num4.checked ){ i++ }
     
     if(i > max) {
          alert("คุณเลือกมากกว่า "+max+" เบอร์");
          return false;
     }else if(i < max ){
          alert("คุณเลือกน้อยกว่า "+max+" เบอร์")
          return false;
     }
    
}
</script>
        
    </body>
</html>
