<?php
        include 'session';
        require 'connectdb.php';
        session_start();
        
        $samo_num = $_GET['samo_num'];
        $samo_name = $_GET['samo_name'];
        $samo_fac = $_GET['samo_fac'];
        
      
        $query = "SELECT * FROM samo_team  WHERE faculty = '$samo_fac'";            
        
        $result = mysqli_query($dbcon, $query);
        
        $query1 = "SELECT * FROM electionset_samo WHERE electionset_faculty = '$samo_fac' ";
        $result1 = mysqli_query($dbcon, $query1);
        $row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
        
         $year = $row1['electionset_year'];
        $electionday = $row1['electionset_date']; 
        $starttime = $row1['electionset_starttime'];
        $endtime = $row1['electionset_endtime'];
        $std_id = $row2['std_id'];

        $today = date("Y-m-d");
        $todaytime = date("H:i:s");
       
        $difdate = $electionday - $today;
        $diftime1 = $todaytime - $starttime;
        $diftime2 = $endtime - $todaytime;
        
        $date1= "$electionday"; //เวลาที่นำไปแปลง แสดงหน้าเลือกตั้ง
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
         <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <?php
                    include 'header.php';
        ?>
        <br><br>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom ">
             
              
            <h1>ข้อมูลผู้สมัคเลือกตั้งสโมสรนักศึกษา คณะ<?php echo $samo_fac ?> </h1><br><br>
            
            <h><font size="4">การเลือกตั้งจะเริ่มภายในวันที่ <?php list($y,$m,$d)=explode('-',$date1); echo$d.'/'.$m.'/'.$y; ?> เวลา <?php echo "$starttime" ?> น. ถึง <?php echo "$endtime"; ?> น. </font></h><br>
            <h><font size="4">ณ คณะ<?php echo $samo_fac; ?> </font></h><br>
                <?php if($today == $electionday and $todaytime >= $starttime and $todaytime <= $endtime){                  
                            echo '<div class="uk-alert uk-alert-success"> <h2>ขณะนี้อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                      } else {                
                            echo '<div class="uk-alert uk-alert-warning"> <h2>ขณะนี้ไม่อยู่ในช่วงเวลาเลือกตั้ง</h2> </div>';
                      }?>
            
            <table class="uk-table uk-table-striped">
                <thead>
                <tr align="center" >
                    <th><h2>โลโก้พรรค</h2></th>
                    <th><h2>หมายเลขพรรค</h2></th>
                    <th><h2>ชื่อพรรค</h2></th>
                    <th><h2>รายละเอียด</h2></th>                              
                </tr>
                </thead>
                <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                ?>
                <tbody>
                <tr align="center">
                        <td align="center"><img src="image_samo/logo/<?php echo $row[4];?>" width="100px" height="100px"></td>
                        <form method="GET" action="frm_ongkan_candidate.php">                  
                        <td align="center"><h2><?php echo $row[0];?></h2><input type="hidden" name="samo_num" value="<?php echo $row[0];?>" readonly></td>
                        <td align="center"><h2><?php echo $row[1];?></h2><input type="hidden" name="samo_name"value="<?php echo $row[1];?>" readonly></td>
                        <td align="center"><button type="submit" class="btn btn-secondary" value="สมาชิคพรรค" onClick="this.form.action='show_electionsamo_candi_user.php'; submit()"><h2>สมาชิคพรรค</h2></button></td>
                        </form>
                    </tr>
                </tbody>
                <?php 
                    }
                    mysqli_free_result($result);
                    mysqli_close($dbcon);
                ?>
            </table>
                                     
            </div><!-- end grid -->                  
        
            
    </body>
    <?php
        include 'footer.php';
    ?>
</html>
