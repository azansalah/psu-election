<?php
        require 'connectdb.php';
        $id = $_GET['id'];
        $std_name = $_GET['std_name'];
        $year = $_GET['elect_year'];
        $type = 'fac';
        
      
        $query = "SELECT * FROM sapa_candidate  WHERE year = '$year' AND type = '$type' ORDER BY id ";            
        
        $result = mysqli_query($dbcon, $query);

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
    </head>
        <body>
            <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
            <br><h1>ข้อมูลผู้สมัคเลือกตั้งสภานักศึกษา แบบสัดส่วนคณะ ปีการศึกษา <?php echo "$year"; ?></h1><br><br>
            <button type="button" class="btn btn-secondary" value="เพิ่มสมาชิค" onclick="window.location.href='frm_sapa_candidate.php?elect_year=<?php echo $year?>&type=<?php echo $type; ?>'"><h3>เพิ่มผู้ลงสมัคร</h3></button><br><br><br>
        <table class="table">
            <thead class="thead-dark" >
                <tr align="center">
                    <th scope="col">ลำดับ</th>
                    <th scope="col">รูป</th>                                   
                    <th scope="col">ชื่อ</th>
                    <th scope="col">นามสกุล</th>
                    <th scope="col">รหัสนักศึกษา</th>
                    <th scope="col">คณะ</th>
                    <th scope="col">ชั้นปี</th>             
                    <th scope="col">แก้ไข</th>
                    <th scope="col">ลบ</th>
                </tr>
                <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                ?>
                <tr align="center">
                    <td><h3><?php echo $row['std_num'];?></h3></td>
                    <td><img src="image_sapa/<?php echo $row['std_image'];?>" width="100px" height="100px"></td>                   
                    <td><h3><?php echo $row['std_name'];?></h3></td>
                    <td><h3><?php echo $row['std_lastname'];?></h3></td>
                    <td><h3><?php echo $row['std_id'];?></h3></td>
                    <td><h3><?php echo $row['sapa_fac'];?></h3></td>
                    <td><h3><?php echo $row['std_year'];?></h3></td>
                    
                    <td><a href="update_sapa_candidate.php?id=<?php echo $row['id'];  ?>&type=<?php echo $row['type']; ?>&year=<?php echo $row['year']; ?> " onclick="return confirm('คุณต้องการแก้ไข <?php echo "$row[std_name]"; ?>');">แก้ไข</a></td>
                    <td><a href="delete_sapa_candidate.php?id=<?php echo $row['id']; ?>&type=<?php echo $row['type']; ?>&year=<?php echo $row['year']; ?> " onclick="return confirm('ยืนยันการลบ <?php echo "$row[std_name]"; ?>');">ลบ</a></td>
                </tr>
                <?php 
                    }
                    mysqli_free_result($result);
                    mysqli_close($dbcon);
                ?>
        </table>
            </div>                               
                </div>                      
            </div><!-- end grid -->
              </center>
    </body><br><br>
    <?php
    include 'footer.php';                          
    ?>
  
</html>




