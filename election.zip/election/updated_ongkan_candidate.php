<?php
        require 'connectdb.php';
        $id = $_GET['id'];
        $ongkan_num = $_GET['ongkan_num'];
        $ongkan_name = $_GET['ongkan_name'];
        $std_name = $_GET['std_name'];
        $std_id = $_GET['std_id'];
        $ongkan_fac = $_GET['ongkan_fac'];
        $std_year = $_GET['std_year'];
        $std_pos = $_GET['std_pos'];
        
     $q = "UPDATE ongkan_candidate SET ongkan_num = '$ongkan_num', ongkan_name = '$ongkan_name', std_name = '$std_name', std_id = '$std_id', ongkan_fac = '$ongkan_fac', std_year = '$std_year', std_pos = '$std_pos' WHERE id = '$id' ";   
     $result = mysqli_query($dbcon, $q);
     
     if ($result) {
         header("Location: show_electionongkan.php?ongkan_num=$ongkan_num&ongkan_name=$ongkan_name");
     } else {
         echo "เกิดข้อผิดพลาด" . mysqli_error($dbcon); 
     }
     
     mysqli_close($dbcon);
 