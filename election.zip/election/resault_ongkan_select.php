<?php
        require 'connectdb.php';    
                
        $q = "SELECT * FROM electionset INNER JOIN election_type ON electionset.electionset_name = election_type.election_id WHERE electionset_name = '001' ORDER BY electionset_year";
        $result = mysqli_query($dbcon, $q);
    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <center>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <br>
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
        <br>
        <h1>ผลการเลือกตั้งองค์การบริหาร องค์การนักศึกษา</h1>
        <br><br>
        <table class="table">
            <thead class="thead-dark" >
            <tr align="center">        
                <th scope="col">การเลือกตั้ง</th>
                <th scope="col">ปีการศึกษา</th>
                <th scope="col">วันที่</th>
                <th scope="col">เวลาเริ่มต้น</th>
                <th scope="col">เวลาสิ้นสุด</th>
                <th scope="col">เพิ่มเติม</th>                               
            </tr>
            <?php
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){                           
            ?>
            <tr align="center">
                <form method="GET" action="resault_ongkan.php">
                <td><h3><?php echo $row['election_name'];?></h3><input type="hidden" name="elect_name" value="<?php echo $row['election_name'];?>" size="25" readonly></td>
                <td><h3><?php echo $row['electionset_year'];?></h3><input type="hidden" name="elect_year" value="<?php echo $row['electionset_year'];?>" readonly></td>
                <td><h3><?php echo $row['electionset_date'];?></h3><input type="hidden" name="elect_date" value="<?php echo $row['electionset_date'];?>" readonly></td>
                <td><h3><?php echo $row['electionset_starttime'];?></h3><input type="hidden" name="elect_starttime" value="<?php echo $row['electionset_starttime'];?>" readonly></td>
                <td><h3><?php echo $row['electionset_endtime'];?></h3><input type="hidden" name="elect_endtime" value="<?php echo $row['electionset_endtime'];?>" readonly></td>
                <td><button type="submit" class="btn btn-secondary" ><h3>ดูผลคะแนน</h3></button>
            
                </form>
            </tr>
            <?php 
                    }
                    mysqli_free_result($result);
                    mysqli_close($dbcon);                              
            ?>
        </table>
        </div>                               
                </div>                      
            </div><!-- end grid -->                            
    </body>
    <?php
    include 'footer.php';                          
    ?>
        <br>
    </center>
</html>

