<?php
        require 'connectdb.php';
        $id = $_GET['id'];
        $q = "SELECT * FROM sapa_candidate WHERE id='$id'";
        $res = mysqli_query($dbcon, $q);
        $row1 = mysqli_fetch_array($res, MYSQLI_ASSOC);
        
        $type = $_GET['type'];
        $year = $_GET['year'];
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
                <center>
      <br>
      <h1>แก้ไขข้อมูล ผู้ลงเลือกตั้งองค์การบริหาร องค์การนักศึกษา</h1>
      <br><br> 
    <form action="updated_sapa_candidate.php" method="GET" enctype="multipart/form-data" name="form1" id="form1">
      <fieldset>
            <legend>กรอกข้อมูล</legend>
            <input type="hidden" name="id" value="<?php echo $id ?>">
            <input name="year" type="hidden" id="year" value="<?php echo $year ; ?>" size="20" >
            <input name="type" type="hidden" id="type" value="<?php echo $type ; ?>" size="20" >
          
            <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">เบอร์</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="std_num" id="std_num" value="<?php echo $row1['std_num'];?>">
            </div>
            <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">ชื่อ</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="std_name" id="std_name" value="<?php echo $row1['std_name'];?>">
            </div>
            <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">นามสกุล</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="std_lastname" id="std_lastname" value="<?php echo $row1['std_lastname'];?>">
            </div>
            <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">รหัสนักศึกษา</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="std_id" id="std_id" value="<?php echo $row1['std_id'];?>">
            </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">คณะ</label>
                    <?php
                        $q1 = "SELECT * FROM faculty_type";
                        $result = mysqli_query($dbcon, $q1);
                    ?>
                </div>
                    <select name="sapa_fac" id="sapa_fac" class="custom-select" id="inputGroupSelect01">
                        <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                if ($row[1]==$row1[sapa_fac]){
                                    echo "<option value='$row[1]' selected >$row[1]</option>";                              
                                } else {                                                           
                                    echo "<option value='$row[1]'>$row[1]</option>";
                                }
                            }
                  ?>
                    </select>
            </div>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">ชั้นปี</label>
                    <?php
                        $q2 = "SELECT * FROM std_year";
                        $result2 = mysqli_query($dbcon, $q2);
                    ?>
                </div>
                    <select name="std_year" id="std_year" class="custom-select" id="inputGroupSelect01">
                        <?php
                            while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                                if ($row2[0]==$row1[std_year]){
                                    echo "<option value='$row2[0]' selected >$row2[0]</option>";                              
                                } else {                                                           
                                    echo "<option value='$row2[0]'>$row2[0]</option>";
                                }
                            }
                  ?>
                    </select>
            </div>
           
            <label>รูปภาพ: <input type="file" name="std_image"></label><br>            
            <button name="submit" type="submit" name="submit" value="บันทึก" class="btn btn-secondary" style="width:200px; font-size:18px" >บันทึก</button>
              
      </fieldset>        
      </form>
                </div>                               
            </div>                      
        </div><!-- end grid --> 
        </center>
    </body>
    <?php
    include 'footer.php';                          
    ?>
</html>







