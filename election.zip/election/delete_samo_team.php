<?php
        require 'connectdb.php';
        
        $electionset_id = $_GET['electionset_id'];
        $elect_name = $_GET['elect_name'];
        $elect_fac = $_GET['elect_fac'];
        $elect_year = $_GET['elect_year'];
        $elect_date = $_GET['elect_date'];
        $elect_starttime = $_GET['elect_starttime'];
        $elect_endtime = $_GET['elect_endtime'];
        
        $electionset1_id = $_GET['electionset1_id'];
        $ongkan_num = $_GET['ongkan_num'];
        $ongkan_name = $_GET['ongkan_name'];
        
        $q = "DELETE FROM samo_team WHERE id='$electionset_id'";
        
        $result = mysqli_query($dbcon, $q);
        
        if ($result) {
            header("Location: show_samo_team.php?elect_name=$elect_name&elect_fac=$elect_fac&elect_year=$elect_year&elect_date=$elect_date&elect_starttime=$elect_starttime&elect_endtime=$elect_endtime");
        } else {
            echo "เกิดข้อผิดพลาดในการลบข้อมูล" . mysqli_error($dbcon);
        }
        
        mysqli_close($dbcon);