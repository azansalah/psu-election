<?php
        require 'connectdb.php';
        $q = "SELECT * FROM electionset";
        $result = mysqli_query($dbcon, $q);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>กำหนัดการเลือกตั้ง</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        <h2>กำหนดการเลือกตั้ง</h2>
        <table style="width: 900px">
            <tr>
                <th>การเลือกตั้ง</th>
                <th>วันที่</th>
                <th>แก้ไข</th>
                <th>ลบ</th>
                
            </tr>
            <?php
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            ?>
            <tr>
                <td><?php echo $row['electionset_name']; ?></td>
                <td><?php echo $row['electionset_date']; ?></td>               
                <td><a href="update_one.php?one_number=<?php echo $row['one_number']; ?>">แก้ไข</a></td>
                <td><a href="delete_one.php?one_number=<?php echo $row['one_number']; ?>">ลบ</a></td>
            </tr>
        <?php 
                }
                mysqli_free_result($result);
                mysqli_close($dbcon);
         ?>
    </table>
    </body>
</html>


