<?php
       require 'connectdb.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>main_admin</title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
        <link rel="stylesheet" href="css/uikit.min.css">
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </head>
    <body>
        <?php
                    include 'header_admin.php';                  
        ?>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-5-4" style="font-coler: " >
        <center>
        <br>
        <h1>สร้างการเลือกตั้งสภานักศึกษา</h1>
        <br><br>
        </center>
        <form action="create_election_sapa_insert.php" method="post" enctype="multipart/form-data" id="form1">
            <fieldset>        
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">การเลือกตั้ง</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="electionset_name" id="electionset_name" size="30" value="สภานักศึกษา" readonly>
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">ปีการศึกษา</span>
                    </div>
                        <input type="text" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="year" id="year" value="">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">วันที่</span>
                    </div>
                        <input type="date" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="date" id="date" value="">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">เวลาเริ่มต้น</span>
                    </div>
                        <input type="time" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="starttime" id="starttime" type="time" value="">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">เวลาสิ้นสุด</span>
                    </div>
                        <input type="time" class="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" name="endtime" id="endttime" type="time" value="">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">เกณฑ์คะแนน (แบบทั่วไป)</span>
                    </div>
                        <input type="text" class="form-control" placeholder="กรอกเป็นค่าตัวเลข เช่น 100"  aria-describedby="inputGroup-sizing-default" name="win_score_normal" id="win_score_normal"  value="">
                </div>
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">เกณฑ์เปอร์เซ็นของคะแนนเสียง (แบบสัดส่วนคณะ)</span>
                    </div>
                        <input type="text" class="form-control" placeholder="กรอกเป็นค่าตัวเลข เช่น 50 ตัวอย่าง ผู้ที่ชนะการเลือกตั้งต้องมีผลการรับรองสิทธ์เป็น 50% ของคนที่ลงคะแนนทั้งหมด" aria-describedby="inputGroup-sizing-default" name="win_score_fac" id="win_score_fac" value="">
                </div>
              <center><button name="submit" type="submit" name="submit" value="สร้าง" class="btn btn-secondary" style="width:300px; font-size:18px" >สร้าง</button></center>
            </fieldset>        
        </form>
                </div>                               
            </div>                      
        </div><!-- end grid -->                            
    </body><br><br>
    <?php
    include 'footer.php';                          
    ?>
    
</html>
