<?php
        include 'session';
        require 'connectdb.php';
        session_start();
        $user = $_SESSION['login_username'];
        
        $query = "SELECT * FROM tblogin WHERE login_username ='$user'";
        $result1 = mysqli_query($dbcon, $query);
?>
<html>
    
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="css/uikit.min.css" />
        <script src="js/jquery.js"></script>
        <script src="js/uikit.min.js"></script>
        <title>เพิ่มรายละเอียด</title>
    </head>
    <body>
        <div class="uk-container uk-container-center uk-margin-top uk-margin-large-bottom">
             
            <?php
                    include 'header.php';
                    while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)) {
            ?>
            
            <div class="uk-grid" data-uk-grid-margin> 
                <div class="uk-width-medium-3-4">
                    
                    <form class="uk-form" action="add_info.php" method="post">
                    <fieldset data-uk-margin>
                        
                       <legend>แก้ไขข้อมูล</legend>
                       <input type="text" value="<?php echo $row1[6];?>" name="name"  required><br><br>
                       <input type="text" value="<?php echo $row1[7];?>" name="last_name" required><br><br>
                       <input type="text" value="<?php echo $row1[10];?>" name="std_id" required><br><br>
                       <input type="email" value="<?php echo $row1[3];?>" name="email" required><br><br>
                       
                       <?php
                            $q = "SELECT * FROM faculty_type";
                            $result = mysqli_query($dbcon, $q);
                        ?>
                        <select name="faculty" id="std_fac">                          
                                 <?php
                                    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                        if($row[1]==$row1[8]){
                                            echo "<option value='$row[1]' selected >$row[1]</option>";
                                        }else{
                                    echo "<option value='$row[1]'>$row[1]</option>";
                                        }
                                    }
                                ?>
                        </select><br><br>
                       
                        <select type ="text" name="year" >
                            <option value="<?php echo $row1[9];?>"><?php echo $row1[9];?></option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                        </select><br><br>
                       <input type="submit" value="บันทึกข้อมูล" class="uk-button" > 
                    </fieldset>
                    </form>
                    
                </div>
                <?php 
                    }
                        mysqli_free_result($result1);
                        mysqli_close($dbcon);
                ?>        
                
                <?php
                        include 'right.php';
                ?>
                
            </div><!-- end grid -->                  
        </div>
        
        <?php
                 include 'rs.php';
        ?>
        
    </body>
</html>





