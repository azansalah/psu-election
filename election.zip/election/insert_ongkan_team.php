<?php

        include 'frm_insert_ongkan_team';
        require 'connectdb.php';
        $electionset_id = $_POST['electionset_id'];
        $elect_name = $_POST['elec_name'];      
        $elect_date = $_POST['elect_date'];
        $elect_starttime = $_POST['elect_starttime'];
        $elect_endtime = $_POST['elect_endtime'];
        $team_number = $_POST['team_number'];
        $team_name = $_POST['team_name'];
        $elec_id = $_POST['elec_id'];
        $faculty = $_POST['faculty'];
        $elect_year = $_POST['elect_year'];
        
        //upload image
        $ext = pathinfo(basename($_FILES['team_image']['name']), PATHINFO_EXTENSION);
        $new_image_name = 'img_'.uniqid().".".$ext;
        $image_path = "image_ongkan/logo/";
        $upload_path =$image_path.$new_image_name;
        //uploading
        $success = move_uploaded_file($_FILES['team_image']['tmp_name'], $upload_path);
        if($success==FALSE) {
            echo 'ไม่สามารถอัพโหลดรูปภาพได้';
            exit();
        }
        
        $team_image = $new_image_name;
        
        $q = "INSERT INTO ongkan_team (electionset_id, team_number, team_name, election_year, team_image) VALUES ('$elec_id','$team_number','$team_name', '$elect_year', '$team_image')";
        
        $r = mysqli_query($dbcon, $q);
        
        if ($r) {
            header("Location: show_ongkan_team.php?electionset_id=$electionset_id&elect_name=$elect_name&elect_year=$elect_year&elect_date=$elect_date&elect_starttime=$elect_starttime&elect_endtime=$elect_endtime");         
            } else {
            echo "เกิดข้อผิดพลาด" .mysqli_error($dbcon);
        }

        mysqli_close($dbcon);

