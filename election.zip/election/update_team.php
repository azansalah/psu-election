<?php
        require 'connectdb.php';
        
        $party_number = $_GET['party_number'];
        $qparty = "SELECT * FROM teamdb WHERE party_number='$party_number'";
        $resparty = mysqli_query($dbcon, $qparty);
        $rowparty = mysqli_fetch_array($resparty, MYSQLI_ASSOC);
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>แก้ไขข้อมูล</title>
        <style>
            label {
                        display: block;
            }
        </style>
    </head>
    <body>
        <h2>แก้ไขข้อมูล</h2>
        <form action="updated_team.php" method="post" enctype="multipart/form-data" id="form1">
      <fieldset>
          <legend>แก้ไขข้อมูล</legend>
          <label>ชื่อพรรค: </label><input name="party_name" type="text" id="party_name" size="20" value="<?php echo $rowparty['party_name']; ?>" >
          <label>เบอร์พรรค: </label><input name="party_number" type="text" id="party_number" size="20" value="<?php echo $rowparty['party_number']; ?>" >
          <label>ชื่อ: </label><input name="t_name" type="text" id="t_name" size="20" value="<?php echo $rowparty['t_name']; ?>" >
          <label>สกุล: </label><input name="t_lastname" type="text" id="t_lastname" size="20" value="<?php echo $rowparty['t_lastname']; ?>" >
          <label>รหัสนักศึกษา: </label><input name="t_id" type="text" id="t_id" size="20" value="<?php echo $rowparty['t_id']; ?>" >
          
          <label>คณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result = mysqli_query($dbcon, $q);
          ?>
              <select name="t_faculty" id="t_faculty">

                  <?php
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                if ($row[0]==$rowparty['t_faculty']) {
                                    echo "<option value='$row[0]' selected>$row[1]</option>";
                                } else {                                  
                                echo "<option value='$row[0]'>$row[1]</option>";
                                }
                            }
                  ?>
              </select>

        
           <label>ชั้นปี: </label>
           <?php
                $q = "SELECT * FROM onedb ";
                $result = mysqli_query($dbcon, $q);
          ?>
              <label>ชั้นปี: </label>
           <label>
               <input type="radio" name="t_year" value="1" id="t_year_1" <?php if ($rowparty['t_year']=='1') echo "checked"; ?>>
           ปี1</label>          
           <label>
               <input type="radio" name="t_year" value="2" id="t_year_2" <?php if ($rowparty['t_year']=='2') echo "checked"; ?>>
           ปี2</label>
           <label>              
               <input type="radio" name="t_year" value="3" id="t_year_3" <?php if ($rowparty['t_year']=='3') echo "checked"; ?>>
           ปี3</label>
           <label>               
               <input type="radio" name="t_year" value="4" id="t_year_4" <?php if ($rowparty['t_year']=='4') echo "checked"; ?>>
           ปี4</label>
           <label>              
               <input type="radio" name="t_year" value="5" id="t_year_5" <?php if ($rowparty['t_year']=='5') echo "checked"; ?>>
           ปี5</label>
           <label>    
               <input type="radio" name="t_year" value="6" id="t_year_6" <?php if ($rowparty['t_year']=='6') echo "checked"; ?>>
           ปี6</label>
           
              <br>
              <input type="hidden" name="one_number" value="<?php echo $rowone['one_number']; ?>"> 
              <input name="submit" type="submit" id="submit" value="แก้ไขข้อมูล">
      </fieldset>        
      </form>
    </body>
</html>
