<?php
        require 'connectdb.php';
        
        $faculty_search = $_GET['sapa_faculty'];
        $teamname_search = $_GET['team_name'];
        
        if($faculty_search == "" AND $teamname_search == ""){
            $query = "SELECT * FROM sapa_team ";
        }else if($faculty_search == "" AND $teamname_search != ""){
            $query = "SELECT * FROM sapa_team WHERE team_name = '$teamname_search' ";
        }else if($faculty_search != "" AND $teamname_search == ""){
            $query = "SELECT * FROM sapa_team INNER JOIN faculty_type ON sapa_team.faculty = faculty_type.faculty_name WHERE faculty_id = '$faculty_search'";
        }
        else{
            $query = "SELECT * FROM sapa_team INNER JOIN faculty_type ON sapa_team.faculty = faculty_type.faculty_name WHERE faculty_id = '$faculty_search' AND team_name = '$teamname_search' ";            
        }
        $result1 = mysqli_query($dbcon, $query);
        
?>
<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            table,th,td {
                border: 1px solid black;
                border-collapse: collapse;      
            }
        </style>
    </head>
    <body>
        
        <form method="GET" action="show_sapa_team.php">
            
        <label>เลือกคณะ: </label>
              <?php
                $q = "SELECT * FROM faculty_type";
                $result2 = mysqli_query($dbcon, $q);
              ?>
              <select name="sapa_faculty" id="sapa_faculty">
                  <option value="">---แสดงทั้งหมด---</option>
                  <?php
                            while ($row2 = mysqli_fetch_array($result2, MYSQLI_NUM)) {
                                echo "<option value='$row2[0]'>$row2[1]</option>";
                            }
                  ?>
              </select><br>
              
        <label>ชื่อพรรค: </label>
        <input type="text" name="team_name">
        <br>
        <input type="submit" value="แสดง">
            
        </form>
        
        <br>
        <a href='frm_select_election.php'>กลับไปยัง เลือกประเภทการเลือกตั้ง</a><br>
        <a href='show_electionsapa.php'>แสดงข้อมูลผู้สมัคเลือกตั้งสภานักศึกษา ทั้งหมด</a>
        <h2>ข้อมูลการลงสมัคเลือกตั้งสภานักศึกษา</h2>      
        <table style="width: 600px">
            <tr>
                <th>หมายเลขพรรค</th>
                <th>ชื่อพรรค</th>
                <th>คณะ</th>
                <th>รายละเอียด</th>
            </tr>
        <?php
                //while ($row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC)) {
                while ($row1 = mysqli_fetch_array($result1, MYSQLI_NUM)) {
        ?>
        <tr>
        <form method="GET" action="frm_sapa_candidate.php">
            <td><input type="text" name="sapa_num" value="<?php echo $row1[0];?>" readonly></td>
            <td><input type="text" name="sapa_name" value="<?php echo $row1[1];?>" readonly></td>
            <td><input type="text" name="sapa_fac" value="<?php echo $row1[2];?>" readonly></td>
            <td>
                <input type="submit" value="เพิ่มสมาชิก">
            </form>
            </td>
        </tr>
        <?php 
                }
                mysqli_free_result($result1);
                mysqli_free_result($result2);
                mysqli_close($dbcon);
         ?>
    </table>
    </body>
</html>
